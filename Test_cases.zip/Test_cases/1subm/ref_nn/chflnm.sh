#!/bin/bash
nfl=`cat flst.txt | wc -l`

kw=("UTR5_UTR5" "ORF1ab_nsp1_" "ORF1ab_nsp2" "ORF1ab_nsp3" "ORF1ab_nsp4" "ORF1ab_nsp5AB" "ORF1ab_nsp6" "ORF1ab_nsp7" "ORF1ab_nsp8" "ORF1ab_nsp9" "ORF1ab_nsp10" "ORF1ab_nsp11" "ORF1ab_stemloop1" "ORF1ab_stemloop2" "ORF1ab_nsp12" "ORF1ab_nsp13" "ORF1ab_nsp14" "ORF1ab_nsp15" "ORF1ab_nsp16" "ORF2_spike" "ORF3a_orf3aprotein" "ORF4_eprotein" "ORF5_mprotein" "ORF6_orf6protein" "ORF7a_orf7aprotein" "ORF7b_orf7bprotein" "ORF8_orf8protein" "ORF9_nprotein" "ORF10_orf10protein" "ORF10_stemloop1" "ORF10_stemloop2" "UTR3_UTR3")

for ((i=0; i<32; i++))
do
    #flnm=`cat flst.txt | head -$i | tail -1`
    #mv $flnm "ref_"$flnm
    flnm="ref_"${kw[$i]}"_nn.fasta"
    seqcnt=`tail -n +2 $flnm | tr -d "\n\r" | tr -d " " | wc -m`
    echo -e $flnm"\t"$seqcnt >> seqcnt.txt
done
