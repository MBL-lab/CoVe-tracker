'''
    Author 		: 	Murali Aadhitya M S
    Modified 	:	17 January 2022 12:58:28 (V.5) 
	Note: 
        > This code runs only in systems with sed, grep, awk and preinstalled blast packages in Linux
        > Execution format - python 'code_file' 'sequence_file' 'metadata_file'
	    > Version 6 - Made changes to work with new format of metadata
    	> Version 7 - Includes Host data in unq_seqs and seq_combn files; removed mose comments and cleaned code.
		> Version 8 - Corrected folder creation error for new format
		> Version 10 - date error exception handling
'''

# Libraries and modules
import datetime             #Used for time
import os                   #Used for directory handling
import sys                  #Used to get arguments while running the script
import subprocess as sp     #Used to run Python scripts internally
import re                   #Used for regular expressions
import shutil               #Used for files and folder handling
import logging		    #Used to log messages 

# Configuring Logger
LOGFormat= "%(lineno)d \t%(levelname)s \t\t%(asctime)s \t-\t%(message)s"
logging.basicConfig(filename="ProcessLog.log", level=logging.DEBUG, format= LOGFormat, filemode = "w")
logger=logging.getLogger()

# Custom Defined Functions

def grep_func(string_pattern,filename,pos,type):
	'''Grep function as used in Linux. Specify the position of match ("start","mid","end"). If not needed, leave it as "". Type "exl" excludes line matches in result'''
	if pos == "start":
		pre="\A"
		suf=""
	elif pos == "mid":
		pre="\B"
		suf="\B"
	elif pos == "end":
		pre=""
		suf="\Z"
	else:
		pre=""
		suf=""
	with open(filename,"r",encoding="utf-8") as read_var:
		store=[]
		for line in read_var:
			line.rstrip("\n")
			if type=="exl":
				if not re.search(pre+string_pattern+suf,line):
					store.append(line.strip(" \n_"))
			else:
				if re.search(pre+string_pattern+suf,line):
					store.append(line.strip(" \n_"))
		return store
	return ''
def write_time_func(file,time,num):
	'''This function is used to write the time into the given file(Arg1). Arg num is used to mention if it is start time(1) or total time()'''
	analysis_time = open(str(file),"a")
	if num==1:
		analysis_time.write(str("Start time is:"))
	elif num==2:
		analysis_time.write("\n"+str("End time : "))
	else:
		analysis_time.write("\n"+str("Time taken : "))
	analysis_time.write(str(time)+"\n")
	analysis_time.close()
def ymd_func(date_var,infmt,outfmt):
	'''Terms: d - date (1 - 31)
	m - month as number (1-12)
	s - short month (Jan, Feb,.., Dec)
	l - long month (January, February,.., December)
	y - short year (19, 20, ..)
	Y - long year (2019, 2020, ..)
	Default "" format is "Y-m-d";
	Input values (infmt): "Y-m-d"; "d/m/Y".
	Leaving null for outfmt will return same format as input format.
	Output format types accepted : ""; "d-s-y"; "d-l-Y"; "l-Y"; "lY"; "sY"; "s-y"; "d-m-y"; "d-m-Y"; "sy"; '''
	if infmt=="Y-m-d": fmtin="%Y-%m-%d"
	elif infmt=="d/m/Y": fmtin="%d/%m/%Y"
	else: fmtin="%Y-%m-%d"
	if outfmt=="d-m-y": fmtout="%d-%m-%y"
	elif outfmt=="d-m-Y": fmtout="%d-%m-%Y"
	elif outfmt=="sy": fmtout="%b%y"
	elif outfmt=="s-y": fmtout="%b-%y"
	elif outfmt=="sY": fmtout="%b%Y"
	elif outfmt=="lY": fmtout="%B%Y"
	elif outfmt=="l-Y": fmtout="%B-%Y"
	elif outfmt=="d-l-Y": fmtout="%d-%B-%Y"
	elif outfmt=="d-s-y": fmtout="%d-%b-%y"
	else: fmtout=fmtin
	
	date_format=datetime.datetime.strptime(date_var,fmtin)
	return date_format.strftime(fmtout)
def cut_func(string,cut_type):
	'''Provide the string and the part to cut. Type variables = "ID", "compID", "Date".'''
	temp1=string.split("|")
	if cut_type == "ID":
		temp2=temp1[1].split("_")
		return temp2[-1]
	elif cut_type=="Date":
		temp2=datetime.datetime.strptime(temp1[2],"%Y-%m-%d")
		return datetime.datetime.strftime(temp2, "%Y-%m-%d")
	elif cut_type=="compID":
		return temp1[1]
def findinfo(pattern_findinfo, file_findinfo):
	'''Enter pattern to search in any csv file and returns the csv results in an array'''
	results_findinfo=grep_func(pattern_findinfo, file_findinfo,"","")
	if len(results_findinfo)!=0:
		array_findinfo=results_findinfo[0].split(",")
		return array_findinfo
	return ""
def getseq_func(id_getseq,filename_getseq):
	'''Custom .fasta file parser'''
	j=0
	with open(filename_getseq,"r",encoding="utf-8") as read_var:
		for line in read_var:
			line.rstrip("\n")
			if j==1:
				return line
			if re.findall(id_getseq,line):
				j=1
def formatfasta(inputfile_formatfasta):
	'''This function calls an external script to modify the contents of the sequence input file. The external script is a bash script that replaces all \n and \r in the seq file.'''
	cmd_format="./formatfasta.sh "+str(inputfile_formatfasta)
	os.system("chmod 700 formatfasta.sh")
	os.system(cmd_format)
def writetoFile(variable_writeto, filename_writeto):
	'''Appends content (variable_writeto) into file (filename_writeto)'''
	temp=open(filename_writeto,"a",encoding="utf-8")
	temp.writelines(variable_writeto)
	temp.write("\n")
	temp.close()
def overwritetoFile(variable_overwrite, filename_overwrite):
	'''Overwrites Content(variable) into File(filename). Creates file if not present. '''
	temp=open(filename_overwrite,"w+",encoding="utf-8")
	temp.writelines(variable_overwrite)
	temp.write("\n")
	temp.close()
def mutposfunc(filename_mutpos,orfname,moltype):
	'''Parses through alignment file (outfmt=3) and returns positions of all mutations(subs and indels)'''
	mut_dict={}
	muts_nt=("A", "T", "C", "G", "a", "c", "t", "g", "-")
	muts_pt=("X" ,"S" ,"L" ,"P" ,"R" ,"T" ,"V" ,"A" ,"G" ,"F" ,"Y" ,"@" ,"C" ,"W" ,"H" ,"Q" ,"I" ,"M" ,"N" ,"K" ,"D" ,"E", "-")
	align_info_ref=grep_func("0 ",filename_mutpos,"start","")
	align_line_qry=grep_func("Query_1",filename_mutpos,"start","")
	if not len(align_info_ref)==len(align_line_qry):
		logger.warning("Alignment results improper")
		return mut_dict
	temp_align=align_info_ref[0].split()
	align_seq_len=len(temp_align[2]) 
	basecount=1
	temp_mutpos={}
	for line_num,align_line in enumerate(align_info_ref):
		ref_align_temp=align_line.split()
		ref_align=str(ref_align_temp[2])
		if moltype=="nt":
			for elem in muts_nt:
				for position in re.finditer(elem, ref_align):
					qry_align_temp=align_line_qry[line_num].split()
					qry_align=qry_align_temp[2]
					temp_mutpos={position.start()+basecount:[elem.upper(),qry_align[position.start()].upper(), orfname] }
					if temp_mutpos.keys():
						mut_dict.update(temp_mutpos)
			basecount+=align_seq_len
		elif moltype=="pt":
			for elem in muts_pt:
				for position in re.finditer(elem, ref_align):
					qry_align_temp=align_line_qry[line_num].split()
					qry_align=qry_align_temp[2]
					temp_mutpos={position.start()+basecount:[elem.upper(),qry_align[position.start()].upper(), orfname] }
					if temp_mutpos.keys():
						mut_dict.update(temp_mutpos)
			basecount+=align_seq_len
	return mut_dict
def readfromFile(filename_readfrom):
	'''Returns File content'''
	file = open(filename_readfrom,"r",encoding="utf-8")
	line = file.read().replace("\n", "")
	file.close()
	return line
def namestore(count_namestore, file_namestore):
	'''Function to store details about type of mutation based on number of mutations'''
	a=""
	if count_namestore>0 or count_namestore<60:
		if os.path.exists(file_namestore):
			a=readfromFile(file_namestore)
			return a
	else:
		if count_namestore==0:
			a=""
			return a
		else:
			a="ERR_lngt60;"
			return a
def checkCreate(directory_create):
	'''To check and create a directory if it does not exist'''
	if not os.path.isdir(directory_create): 
		os.mkdir(directory_create)
def checkRemove(file_remove):
	'''To check and remove a directory if it exists'''
	if os.path.exists(file_remove): 
		os.remove(file_remove)
def appendFiletoFile(fromFile, toFile):
	'''Appends one file (fromFile) content into another file(toFile)'''
	temp1=open(fromFile,"r",encoding="utf-8").read()
	temp2=open(toFile,"a+",encoding="utf-8")
	temp2.write(temp1)
	temp2.close()
def deleteFileType(path,extension):
	'''Deletes all files of specified extension'''
	for file_name in os.listdir(path):
		if file_name.endswith(extension):
			os.remove(path + "/" + file_name)
def collectallmut(dict_muts):
	'''Returns mutation dictionary including the respective ORF names'''
	temp_array=[]
	contents=[]
	for posi,muta in dict_muts.items():
		muta_temp=muta[2].split("_", 1)
		muta[2]=muta_temp[1]
		temp_array=muta
		temp_array.append(posi)
		contents.append(temp_array)
	return contents
def removeX(mut_str):
    string_mut=""
    array=mut_str.split(";")
    for elem in array:
        if elem:
            if not elem[-1]=="X":
                string_mut+=str(elem)+";"
    return string_mut

# Sysytem execution arguments
start_time = datetime.datetime.now()
print("\n\nStart time is",start_time,"\n")
logger.info("Process Started")
cpth = os.getcwd()
logger.info("Working Directory is "+str(cpth))
seq_file_name = sys.argv[1]
metadata_name = sys.argv[2]
nts=("A", "T", "C", "G")
aminoacids=("")
kw={"UTR5_UTR5":[265,0], "ORF1ab_nsp1_":[540,181], "ORF1ab_nsp2":[1914,639], "ORF1ab_nsp3":[5835,1946], "ORF1ab_nsp4":[1500,501], "ORF1ab_nsp5AB":[918,307], "ORF1ab_nsp6":[870,291], "ORF1ab_nsp7":[249,84], "ORF1ab_nsp8":[594,199], "ORF1ab_nsp9":[339,114], "ORF1ab_nsp10":[417,140], "ORF1ab_nsp11":[39,14], "ORF1ab_stemloop1":[28,0], "ORF1ab_stemloop2":[55,0], "ORF1ab_nsp12":[2796,933], "ORF1ab_nsp13":[1803,602], "ORF1ab_nsp14":[1581,528], "ORF1ab_nsp15":[1038,347], "ORF1ab_nsp16":[894,299], "ORF2_spike":[3822,1273], "ORF3a_orf3aprotein":[828,275], "ORF4_eprotein":[228,75], "ORF5_mprotein":[669,222], "ORF6_orf6protein":[186,61], "ORF7a_orf7aprotein":[366,121], "ORF7b_orf7bprotein":[132,43], "ORF8_orf8protein":[366,121], "ORF9_nprotein":[1260,419], "ORF10_orf10protein":[117,38], "ORF10_stemloop1":[36,0], "ORF10_stemloop2":[29,0], "UTR3_UTR3":[229,0]}
utr=("UTR5_UTR5", "UTR3_UTR3", "ORF1ab_stemloop1", "ORF1ab_stemloop2", "ORF10_stemloop1", "ORF10_stemloop2") 
excep_orf=("ORF1ab_stemloop1")
newORF={"COV2_1a_uORF1_ext":[77,25],"COV2_1a_uORF1_0":[29,9],"COV2_1a_uORF2_ext":[101,33],"COV2_S_iORF1":[120,39],"COV2_S_iORF2":[96,31],"COV2_3a_iORF1_ORF3c":[126,41],"COV2_3a_iORF2":[102,33],"COV2_E_iORF":[36,11],"COV2_M_ext":[708,235],"COV2_M_iORF":[45,14],"COV2_6_iORF":[132,43],"COV2_7a_iORF1":[360,119],"COV2_7a_iORF3":[48,15],"COV2_7b_iORF1":[63,20],"COV2_7b_iORF2":[36,11],"COV2_N_iORF1_ORF9b":[294,97],"COV2_N_iORF2":[273,90],"COV2_10_uORF":[33,10],"COV2_10_iORF":[57,18]}
excep_newORF=()
excluded_newORF={"COV2_1a_uORF2_0":[41,13], "COV2_1a_iORF":[17,5], "COV2_7a_iORF2":[27,8], "COV2_8_iORF":[30,9]} 
pp_no=("X","x","0","-")

# Analysis time
write_time_func("Analysis_time.txt",start_time,1)

seq_list=grep_func(">",seq_file_name,"start","")
logger.debug("Sequence file formatted.")
formatfasta(seq_file_name)

print ("The given sequence file is :"+seq_file_name+"\n")
print("The given metadata file is :"+metadata_name+"\n")
print("The number of sequences in given file :"+str(len(seq_list))+"\n")
location=""
host=""
age=""
gender=""
clade=""
pango_lineage=""
continent=""
country="Undefined"
place="Undefined"

for x in range(1, len(seq_list)+1):
	cncl="INCL"
	pp_mutallnm=[]
	pp_mutallnm_newORF=[]
	mutallnm=[]
	mutallnm_newORF=[]
	qry_identity=0
	inprog_seq_desc=seq_list[x-1]
	logger.info("SL:"+str(x)+" -"+str(inprog_seq_desc))
	inprog_seq_clean=inprog_seq_desc.replace(">","")

	metadata_info=findinfo(inprog_seq_clean,metadata_name)
	if not metadata_info:
		writetoFile(str(x)+","+str(inprog_seq_clean)+"_ERR: Metadata Missing","../data_"+phs+"/problem_seq.dat")
		logger.critical("Metadata not found for "+str(inprog_seq_clean))
		continue
	#logger.info("Metadata Info Found")

	#Values from metadata
	# Metadata Format:0-strain,1-virus,2-gisaid_epi_isl,3-genbank_accession,4-date,5-region,6-country,7-division,
	# 8-location,9-region_exposure,10-country_exposure,11-division_exposure,12-segment,13-length,14-host,15-age,
	# 16-sex,17-Nextstrain_clade,18-pangolin_lineage,19-GISAID_clade,20-originating_lab,21-submitting_lab,
	# 22-authors,23-url,24-title,25-paper_url,26-date_submitted,27-purpose_of_sequencing

	cID=metadata_info[2].strip()
	flid=cID.split("|")[-1]
	fldt=metadata_info[4].strip()
	try:
		print(datetime.datetime.strptime(fldt,"%Y-%m-%d"))
	except:
		logger.error(str(flid)+":Error in cltn date format")
		continue
	phase=ymd_func(fldt,"","sy").replace(" ","_")
	phs=str(phase).lower().replace(" ","_")
	continent=metadata_info[5].strip().replace(" ","_")
	country=metadata_info[6].strip().replace(" ","_")
	place=metadata_info[7].strip().replace(" ","_")
	host=metadata_info[14].strip().replace(" ","_")
	age=metadata_info[15].strip().replace(" ","_")
	gender=metadata_info[16].strip().replace(" ","_")
	clade=metadata_info[19].strip().replace(" ","_")
	pango_lineage=metadata_info[18].strip().replace(" ","_")
	subm_date=ymd_func(metadata_info[26],"Y-m-d","Y-m-d")
	if not subm_date:
		subm_date=datetime.datetime.strptime("2025-12-31", "%d-%b-%Y")
	logger.debug("Obtained Metadata Values.")

	#Making required directories:
	checkCreate("../data_"+phs)
	checkCreate("../data_"+phs+"/CDR_seq")
	checkCreate("../data_"+phs+"/CDR_seq/newORF")
	checkCreate("../data_"+phs+"/unqseq_file")
	checkCreate("../data_"+phs+"/"+country)
	checkCreate("../data_"+phs+"/"+country+"/newORF")
	checkCreate("../data_"+phs+"/"+country+"/"+flid)
	checkCreate("../data_"+phs+"/"+country+"/"+flid+"/newORF")
	#logger.debug("Created Required Directories.")

	# logger.info("Sequence is "+getseq_func(cID,seq_file_name))
	inprog_seq_compl=getseq_func(inprog_seq_clean,seq_file_name)
	inprog_seq_len=len(inprog_seq_compl)
	logger.debug("Obtained Sequence Information.")
	#logger.info("Sequence length is "+str(inprog_seq_len))

	if inprog_seq_len > 0:
		overwritetoFile(inprog_seq_desc,"new.fasta")
		writetoFile(inprog_seq_compl,"new.fasta")
	shutil.copy("new.fasta","../data_"+phs+"/"+country+"/"+str(flid)+"/aseq_"+str(flid)+".fasta")

	if os.path.getsize("new.fasta") == 0:
		writetoFile(x+","+str(flid)+",seq_selection_problem","../data_"+phs+"/problem_seq.dat")
	#logger.debug("BLAST and Alignment of WG started.")
	#os.system("makeblastdb -in ref_seq_wg_NC_045512_2.fasta -dbtype nucl")
	os.system("blastn -query new.fasta -db ref_seq_wg_NC_045512_2.fasta -outfmt 10 > aseq_wg_blast.out")
	os.system("blastn -query new.fasta -db ref_seq_wg_NC_045512_2.fasta -outfmt 3 > aseq_wg_align.txt")
	logger.debug("BLAST and Alignment of WG done.")
	nfreq=inprog_seq_compl.count("n")+inprog_seq_compl.count("N")
	nperc=nfreq/inprog_seq_len
	nfrag=sum(1 for line in open("aseq_wg_blast.out"))
	ref_len=29903
	qry_len=inprog_seq_len
	wgdiff=ref_len-qry_len

	if wgdiff<0:
		rmrk="Long("+str(wgdiff)+")"
	elif wgdiff>0:
		rmrk="Short("+str(wgdiff)+")"
	else:
		rmrk="Equal"
	
	sub_count=0
	del_count=0
	ins_count=0
	mut_count=0
	tempseq=""

	if nfrag==1:
		#logger.info("fragments = 1")
		frgn="ONE"
		logger.debug("Handling BLAST results of 1 fragment; nfrag=1.")
		blast_results=findinfo(inprog_seq_clean,"aseq_wg_blast.out")
		align_len=blast_results[3]
		qry_identity=blast_results[2]
		qry_iden_cut=blast_results[2].split(".")
		qry_idnt=qry_iden_cut[0]
		qon=int(blast_results[6])
		ron=int(blast_results[8])
		mismatch=blast_results[4]
		subname=""
		delname=""
		insname=""
		#logger.debug("Done handling BLAST results in array.")
		#logger.info("Query identity is "+str(qry_idnt))
		if qry_idnt!=100:
			mut_position=mutposfunc("aseq_wg_align.txt","WG","nt")
			mut_position={int(k)+ron-1:v for k, v in mut_position.items()}
			for position, aa in mut_position.items():
				mutation=str(aa[0])+str(position)+str(aa[1])+";"
				if aa[0]=="-" and aa[1] in nts:
					writetoFile(mutation,"aseq_"+str(flid)+"_ins_nn.txt")
					ins_count+=1
					mut_count+=1
				elif aa[0]=="-" and aa[1] not in nts:
					writetoFile(mutation,"aseq_"+str(flid)+"_trbl_nn.txt")
				elif aa[0] in nts and aa[1]=="-":
					writetoFile(mutation,"aseq_"+str(flid)+"_del_nn.txt")
					del_count+=1
					mut_count+=1
				elif aa[0] in nts and aa[1] not in nts:
					writetoFile(mutation,"aseq_"+str(flid)+"_trbl_nn.txt")
				else:
					writetoFile(mutation,"aseq_"+str(flid)+"_sub_nn.txt")
					sub_count+=1
					mut_count+=1
			delname=namestore(del_count,"aseq_"+str(flid)+"_del_nn.txt")
			insname=namestore(ins_count,"aseq_"+str(flid)+"_ins_nn.txt")
			subname=namestore(sub_count,"aseq_"+str(flid)+"_sub_nn.txt")
			#logger.debug("Stored WG mutation details in resp txt files.")
#		else:
#			subname=""
#			delname=""
#			insname=""
	else:
		#logger.info("nfrag != 1")
		frgn="MLTPL"
		align_len="NA;"
		mut_count="NA;"
		mismatch="NA;"
		ins_count="NA;"
		del_count="NA;"
		subname=""
		delname=""
		insname=""

	mutallnm=str(subname)+str(delname)+str(insname)
	mutallnm=mutallnm.replace("None","")

	#logger.debug("Generating NN database:")
	#os.system("makeblastdb	 -in refseq_nn_NC_045512_2.fsa -dbtype nucl")
	logger.debug("Performing BLAST wrt 32 ORFs.")
	os.system("blastn -query new.fasta -db refseq_nn_NC_045512_2.fsa -outfmt 10 > aseq_nn_blast.out")

	prend=1
	for orf,pos in kw.items():
		logger.debug("Starting analysis of "+str(orf))
		cdrrmrk=";"
		tempseq=""
		checkRemove("aanew.txt")
		checkRemove("aanew_pp.txt")
		cdr_count=sum(1 for elem in grep_func(orf,"aseq_nn_blast.out","",""))
		blast_orf=findinfo(orf,"aseq_nn_blast.out")
		if not blast_orf:
			writetoFile(str(x)+","+str(flid)+"_ERR: "+orf+" BLAST Fail,"+str(cdr_count),"../data_"+phs+"/problem_seq.dat")
			logger.warning("BLAST Failed for "+str(orf))
			continue
		start_pos=int(blast_orf[6])
		start_space=start_pos-prend
		if start_space>1:
			start_gap=prend+1
			end_gap=start_pos-1
			writetoFile(">Seq_gap_"+orf,"aseq_gap.fsa")
			writetoFile(inprog_seq_compl[start_gap+1:end_gap+1],"aseq_gap.fsa")
		end_pos=int(blast_orf[7])
		nmut=blast_orf[4]
		prend=end_pos
		writetoFile("\n>aseq_"+country+"_"+str(flid)+"_"+orf,"aseq_nn.fsa")
		overwritetoFile("\n>aseq_"+country+"_"+str(flid)+"_"+orf, "CDR_nn.fasta")
		cnf=len(re.findall("nsp12",orf))
		#logger.info("CNF = "+str(cnf)+"; CDR count = "+str(cdr_count))
		if cnf==0:
			if cdr_count==1:
				if end_pos>start_pos:
					overwritetoFile(inprog_seq_compl[start_pos-1:end_pos],"aanew.txt")
				else:
					overwritetoFile(inprog_seq_compl[end_pos-1:start_pos],"aanew.txt")
			else:
				writetoFile(str(x)+","+str(flid)+"_ERR: "+orf+","+str(cdr_count),"../data_"+phs+"/problem_seq.dat")
		else:
			if cdr_count==1:
				if end_pos>start_pos:
					tempseq=inprog_seq_compl[start_pos-1:start_pos+26]+inprog_seq_compl[start_pos+25:end_pos]
					overwritetoFile(tempseq,"aanew.txt")
				else:
					tempseq=inprog_seq_compl[end_pos-1:end_pos+26]+inprog_seq_compl[end_pos+25:start_pos]
					overwritetoFile(inprog_seq_compl[end_pos-1:start_pos],"aanew.txt")
			else:
				writetoFile(str(x)+","+str(flid)+"_ERR: "+orf+","+str(cdr_count),"../data_"+phs+"/problem_seq.dat")
		if not os.path.exists("aanew.txt"):
			logger.warning("aanew.txt NOT CREATED.cnf = "+str(cnf)+"; CDR_count = "+str(cdr_count))
			logger.debug("Moving to next ORF")
		else:
			#logger.debug("aanew.txt created and ORF region stored")
			cdr_len=len(readfromFile("aanew.txt"))
			cdr_diff=cdr_len-pos[0]
			appendFiletoFile("aanew.txt","aseq_nn.fsa")
			appendFiletoFile("aanew.txt","CDR_nn.fasta")
			#logger.debug("CDR_nn.fasta created for "+str(orf))
			if cdr_diff>0:
				if cdr_diff>=60:
					cdrrmrk="ERR_lngt_60("+str(cdr_diff)+");"
				else:
					cdrrmrk="Long("+str(cdr_diff)+");"
			elif cdr_diff<0:
				if cdr_diff<=-60:
					cdrrmrk="ERR_lngt_60("+str(cdr_diff)+");"
				else:
					cdrrmrk="Short("+str(cdr_diff)+");"

			writetoFile(str(flid)+","+orf+","+str(pos[0])+","+str(cdr_len)+","+str(cdr_diff),"../data_"+phs+"/CDRcalc.csv")
			ncdr=readfromFile("aanew.txt").count("n")+readfromFile("aanew.txt").count("N")
			xfreq=0
			if orf not in utr:
				tp="NOR"
				#logger.debug(str(orf)+" not in UTR")
				os.system("python translation_code.py")
				xfreq=readfromFile("aanew_pp.txt").count("x")+readfromFile("aanew_pp.txt").count("X")
				os.system("sed -i 's/0/X/g' aanew_pp.txt")			
				writetoFile("\n>aseq_pp_"+country+"_"+str(flid)+"_"+orf,"aseq_pp.fasta")
				overwritetoFile("\n>aseq_pp_"+country+"_"+str(flid)+"_"+orf,"CDR_pp.fasta")
				appendFiletoFile("aanew_pp.txt","aseq_pp.fasta")
				appendFiletoFile("aanew_pp.txt","CDR_pp.fasta")

				if ncdr<=1 and cdr_count==1:
					#logger.debug("Performing BLASTn for "+str(orf))
					#os.system("makeblastdb	 -in ref_nn/ref_"+orf+"_nn.fasta -dbtype nucl")
					os.system("blastn -query CDR_nn.fasta -db ref_nn/ref_"+orf+"_nn.fasta -outfmt 10 > aseq_nn_"+orf+"_blast.out")
					os.system("blastn -query CDR_nn.fasta -db ref_nn/ref_"+orf+"_nn.fasta -outfmt 3 > aseq_nn_"+orf+"_align.txt")
					nblast_results=findinfo(flid,"aseq_nn_"+orf+"_blast.out")
					if not nblast_results:
						writetoFile(str(x)+","+str(flid)+"_ERR: "+orf+" nBLAST Fail,"+str(cdr_count),"../data_"+phs+"/problem_seq.dat")
						logger.warning("nBLAST Failed for "+str(orf))
						continue
					n_identity=nblast_results[2]
					n_iden_cut=nblast_results[2].split(".")
					n_iden=n_iden_cut[0]
					nqon=int(nblast_results[6])
					nron=int(nblast_results[8])
					nmismatch=nblast_results[4]
					cdr_del_name=""
					cdr_ins_name=""
					cdr_sub_name=""
					pp_cdr_del_name=""
					pp_cdr_ins_name=""
					pp_cdr_sub_name=""
					cdr_mut_count=0
					cdr_ins_count=0
					cdr_del_count=0
					cdr_sub_count=0
					trbl_count=0
					ins_rem=0
					del_rem=0
					if n_iden!=100:
						#logger.info("N_Identity != 100")
						cdr_mut_position=mutposfunc("aseq_nn_"+orf+"_align.txt", orf, "nt")
						cdr_mut_position={int(k)+nron-1:v for k, v in cdr_mut_position.items()}
						for position_cdr, aa_cdr in cdr_mut_position.items():
							cdr_mutation=str(aa_cdr[0])+str(position_cdr)+str(aa_cdr[1]+";")
							if aa_cdr[0]=="-" and aa_cdr[1] in nts:
								writetoFile(cdr_mutation,"aseq_"+str(flid)+"_"+orf+"_ins_nn.txt")
								cdr_ins_count+=1
								cdr_mut_count+=1
							elif aa_cdr[0]=="-" and aa_cdr[1] not in nts:
								writetoFile(cdr_mutation,"aseq_"+str(flid)+"_"+orf+"_trbl_nn.txt")
							elif aa_cdr[0] in nts and aa_cdr[1]=="-":
								writetoFile(cdr_mutation,"aseq_"+str(flid)+"_"+orf+"_del_nn.txt")
								cdr_del_count+=1
								cdr_mut_count+=1
							elif aa_cdr[0] in nts and aa_cdr[1] not in nts:
								writetoFile(cdr_mutation,"aseq_"+str(flid)+"_"+orf+"_trbl_nn.txt")
							else:
								writetoFile(cdr_mutation,"aseq_"+str(flid)+"_"+orf+"_sub_nn.txt")
								cdr_sub_count+=1
								cdr_mut_count+=1
						#logger.debug("Stored NN mutations")
						ins_rem=cdr_ins_count%3
						del_rem=cdr_del_count%3
						cdr_del_name=namestore(cdr_del_count,"aseq_"+str(flid)+"_"+orf+"_del_nn.txt")
						if not cdr_del_name: cdr_del_name=""
						cdr_ins_name=namestore(cdr_ins_count,"aseq_"+str(flid)+"_"+orf+"_ins_nn.txt")
						if not cdr_ins_name: cdr_ins_name=""
						cdr_sub_name=namestore(cdr_sub_count,"aseq_"+str(flid)+"_"+orf+"_sub_nn.txt")
						if not cdr_sub_name: cdr_sub_name=""
						if ins_rem!=0 or del_rem!=0:
							tp="FMS"
						if cdr_ins_count>0:
							if cdr_diff>=60:
								appendFiletoFile("CDR_nn.fasta","../data_"+phs+"/"+country+"/"+orf+"_nn_ins_err60.fasta")
								if tp=="FMS":
									continue
								else:
									appendFiletoFile("CDR_pp.fasta","../data_"+phs+"/"+country+"/"+orf+"_pp_ins_err60.fasta")
							else:
								appendFiletoFile("CDR_nn.fasta","../data_"+phs+"/"+country+"/"+orf+"_nn_ins.fasta")
								appendFiletoFile("CDR_nn.fasta","../data_"+phs+"/CDR_seq/"+orf+"_nn_ins.fasta")
								if tp=="FMS":
									continue
								else:
									appendFiletoFile("CDR_pp.fasta","../data_"+phs+"/"+country+"/"+orf+"_pp_ins.fasta")
									appendFiletoFile("CDR_pp.fasta","../data_"+phs+"/CDR_seq/"+orf+"_pp_ins.fasta")
						else:
							if cdr_diff<=-60:
								appendFiletoFile("CDR_nn.fasta","../data_"+phs+"/"+country+"/"+orf+"_nn_err60.fasta")
								if tp=="FMS":
									continue
								else:
									appendFiletoFile("CDR_pp.fasta","../data_"+phs+"/"+country+"/"+orf+"_pp_err60.fasta")
							else:
								appendFiletoFile("CDR_nn.fasta","../data_"+phs+"/"+country+"/"+orf+"_nn.fasta")
								appendFiletoFile("CDR_nn.fasta","../data_"+phs+"/CDR_seq/"+orf+"_nn.fasta")
								if tp=="FMS":
									continue
								else:
									appendFiletoFile("CDR_pp.fasta","../data_"+phs+"/"+country+"/"+orf+"_pp.fasta")
									appendFiletoFile("CDR_pp.fasta","../data_"+phs+"/CDR_seq/"+orf+"_pp.fasta")
						#logger.debug("Copied NN fasta files to Country/ID folders")
						#logger.debug("Performing BLASTp for "+str(orf))
						#os.system("makeblastdb	 -in ref_pp/ref_"+orf+".fasta -dbtype prot")
						os.system("blastp -db ref_pp/ref_"+orf+".fasta -query CDR_pp.fasta -outfmt 10 > aseq_pp_"+orf+"_blast.out")
						os.system("blastp -db ref_pp/ref_"+orf+".fasta -query CDR_pp.fasta -outfmt 3 > aseq_pp_"+orf+"_align.txt")
						pblast_results=findinfo(flid,"aseq_pp_"+orf+"_blast.out")
						if not pblast_results:
							writetoFile(str(x)+","+str(flid)+"_ERR: "+orf+" pBLAST Fail,"+str(cdr_count),"../data_"+phs+"/problem_seq.dat")
							logger.warning("pBLAST Failed for "+str(orf))
							continue
						p_identity=pblast_results[2]
						p_iden_cut=pblast_results[2].split(".")
						p_iden=p_iden_cut[0]
						p_qon=int(pblast_results[6])
						p_ron=int(pblast_results[8])
						p_mismatch=pblast_results[4]
						pp_sub_count=0
						pp_mut_count=0
						pp_ins_count=0
						pp_del_count=0

						if p_iden!=100:
							#logger.info("P_Identity != 100")
							temp_pp_muts=[]
							pp_mut_position=mutposfunc("aseq_pp_"+orf+"_align.txt", orf, "pt")
							pp_mut_position={int(k)+p_ron-1:v for k, v in pp_mut_position.items()}
							if pp_mut_position:
								temp_pp_muts=collectallmut(pp_mut_position)
								pp_mutallnm.extend(temp_pp_muts)
							for position_pp, aa_pp in pp_mut_position.items():
								pp_mutation=str(aa_pp[0])+str(position_pp)+str(aa_pp[1]+";")
								if aa_pp[0] not in pp_no:
									if aa_pp[1] not in pp_no:
										writetoFile(pp_mutation,"aseq_"+str(flid)+"_"+orf+"_sub_pp.txt")
										pp_sub_count+=1
										pp_mut_count+=1
									elif aa_pp[1]=="-" :
										writetoFile(pp_mutation,"aseq_"+str(flid)+"_"+orf+"_del_pp.txt")
										pp_del_count+=1
										pp_mut_count+=1
									else:
										writetoFile(pp_mutation,"aseq_"+str(flid)+"_"+orf+"_trbl_pp.txt")
										trbl_count+=1
								elif aa_pp[0]=="-":
									writetoFile(pp_mutation,"aseq_"+str(flid)+"_"+orf+"_ins_pp.txt")
									pp_ins_count+=1
									pp_mut_count+=1
								else:
									writetoFile(pp_mutation,"aseq_"+str(flid)+"_"+orf+"_trbl_pp.txt")
									trbl_count+=1
							pp_cdr_sub_name=namestore(pp_sub_count,"aseq_"+str(flid)+"_"+orf+"_sub_pp.txt")
							if not pp_cdr_sub_name: pp_cdr_sub_name=""
							pp_cdr_del_name=namestore(pp_del_count,"aseq_"+str(flid)+"_"+orf+"_del_pp.txt")
							if not pp_cdr_del_name: pp_cdr_del_name=""
							pp_cdr_ins_name=namestore(pp_ins_count,"aseq_"+str(flid)+"_"+orf+"_ins_pp.txt")
							if not pp_cdr_ins_name: pp_cdr_ins_name=""
							#logger.debug("Stored PP mutations")
							if pp_ins_count>0:
								cdrrmrk=cdrrmrk+"INSERT;"
							overwritetoFile(country+","+fldt+","+str(flid)+","+orf+","+str(n_identity)+","+str(p_identity)+","+str(cdr_sub_name)+str(cdr_del_name)+str(cdr_ins_name)+","+str(pp_cdr_sub_name)+str(pp_cdr_del_name)+str(pp_cdr_ins_name)+","+cdrrmrk+","+tp+","+str(trbl_count), "aseq_"+str(flid)+"CDRmutinfo.csv")
						else:
							#logger.info("P_Identity = 100")
							trbl_count=sum(1 for line in open("aseq_"+str(flid)+"_"+orf+"_trbl_nn.txt"))
							writetoFile(country+","+fldt+","+str(flid)+","+orf+","+str(n_identity)+","+str(p_identity)+","+str(cdr_sub_name)+str(cdr_del_name)+str(cdr_ins_name)+",NA;,"+cdrrmrk+","+tp+","+str(trbl_count), "aseq_"+str(flid)+"CDRmutinfo.csv")
					else:
						#logger.info("N_identity = 100")
						if ins_rem!=0 or del_rem!=0:
							tp="FMS"
						if cdr_ins_count>0:
							cdrrmrk=cdrrmrk+"INSERT;"
							if cdr_diff>=60:
								appendFiletoFile("CDR_nn.fasta","../data_"+phs+"/"+country+"/"+orf+"_nn_ins_err60.fasta")
								if tp=="FMS":
									continue
								else:
									appendFiletoFile("CDR_pp.fasta","../data_"+phs+"/"+country+"/"+orf+"_pp_ins_err60.fasta")
							else:
								appendFiletoFile("CDR_nn.fasta","../data_"+phs+"/"+country+"/"+orf+"_nn_ins.fasta")
								appendFiletoFile("CDR_nn.fasta","../data_"+phs+"/CDR_seq/"+orf+"_nn_ins.fasta")
								if tp=="FMS":
									continue
								else:
									appendFiletoFile("CDR_pp.fasta","../data_"+phs+"/"+country+"/"+orf+"_pp_ins.fasta")
									appendFiletoFile("CDR_pp.fasta","../data_"+phs+"/CDR_seq/"+orf+"_pp_ins.fasta")
						else:
							if cdr_diff<=-60:
								appendFiletoFile("CDR_nn.fasta","../data_"+phs+"/"+country+"/"+orf+"_nn_err60.fasta")
								if tp=="FMS":
									continue
								else:
									appendFiletoFile("CDR_pp.fasta","../data_"+phs+"/"+country+"/"+orf+"_pp_err60.fasta")
							else:
								appendFiletoFile("CDR_nn.fasta","../data_"+phs+"/"+country+"/"+orf+"_nn.fasta")
								appendFiletoFile("CDR_nn.fasta","../data_"+phs+"/CDR_seq/"+orf+"_nn.fasta")
								if tp=="FMS":
									continue
								else:
									appendFiletoFile("CDR_pp.fasta","../data_"+phs+"/"+country+"/"+orf+"_pp.fasta")
									appendFiletoFile("CDR_pp.fasta","../data_"+phs+"/CDR_seq/"+orf+"_pp.fasta")
						trbl_count=0
						writetoFile(country+","+fldt+","+str(flid)+","+orf+","+str(n_identity)+",100.000,NA;,NA;,"+cdrrmrk+","+tp+","+str(trbl_count), "aseq_"+str(flid)+"CDRmutinfo.csv")
						#logger.debug("Copied CDR_NN and CDR_PP files to Country/ID/")
				else:
					if xfreq!=0:
						writetoFile(str(x)+","+str(flid)+"_X_Freq: "+orf+" = "+str(xfreq),"../data_"+phs+"/problem_seq.dat")
					writetoFile(str(x)+","+str(flid)+","+country+","+orf+","+str(ncdr)+","+str(xfreq)+","+str(cdr_count)+","+cdrrmrk, "../data_"+phs+"/excludeseq.csv")
					cncl="EXCL"
					logger.info("cncl=EXCL")
			elif orf in utr and orf not in excep_orf:
				#logger.info(str(orf)+" in UTR")
				if ncdr==0:
					tp="NCR"
					#logger.debug("Performing BLASTn for "+str(orf))
					#os.system("makeblastdb	 -in ref_nn/ref_"+orf+"_nn.fasta -dbtype nucl")
					os.system("blastn -query CDR_nn.fasta -db ref_nn/ref_"+orf+"_nn.fasta -outfmt 10 > aseq_nn_"+orf+"_blast.out")
					os.system("blastn -query CDR_nn.fasta -db ref_nn/ref_"+orf+"_nn.fasta -outfmt 3 > aseq_nn_"+orf+"_align.txt")
					nblast_results=findinfo(flid,"aseq_nn_"+orf+"_blast.out")
					if not nblast_results:
						writetoFile(str(x)+","+str(flid)+"_ERR: "+orf+" nBLAST Fail,"+str(cdr_count),"../data_"+phs+"/problem_seq.dat")
						logger.warning("nBLAST Failed for "+str(orf))
						continue
					n_identity=nblast_results[2]
					n_iden_cut=nblast_results[2].split(".")
					n_iden=n_iden_cut[0]
					nqon=int(nblast_results[6])
					nron=int(nblast_results[8])
					nmismatch=nblast_results[4]
					cdr_del_name=""
					cdr_ins_name=""
					cdr_sub_name=""
					cdr_mut_count=0
					cdr_ins_count=0
					cdr_del_count=0
					cdr_sub_count=0
					ins_rem=0
					del_rem=0
					trbl_count=0
					if n_iden!=100:
						#logger.info("N_Identity != 100")
						if ins_rem!=0 or del_rem!=0:
							tp="NCR"
						cdr_mut_position=mutposfunc("aseq_nn_"+orf+"_align.txt", orf, "nt")
						cdr_mut_position={int(k)+nron-1:v for k, v in cdr_mut_position.items()}
						for position_cdr, aa_cdr in cdr_mut_position.items():
							cdr_mutation=str(aa_cdr[0])+str(position_cdr)+str(aa_cdr[1]+";")
							if aa_cdr[0]=="-" and aa_cdr[1] in nts:
								writetoFile(cdr_mutation,"aseq_"+str(flid)+"_"+orf+"_ins_nn.txt")
								cdr_ins_count+=1
								cdr_mut_count+=1
							elif aa_cdr[0]=="-" and aa_cdr[1] not in nts:
								writetoFile(cdr_mutation,"aseq_"+str(flid)+"_"+orf+"_trbl_nn.txt")
								trbl_count+=1
							elif aa_cdr[0] in nts and aa_cdr[1]=="-":
								writetoFile(cdr_mutation,"aseq_"+str(flid)+"_"+orf+"_del_nn.txt")
								cdr_del_count+=1
								cdr_mut_count+=1
							elif aa_cdr[0] in nts and aa_cdr[1] not in nts:
								writetoFile(cdr_mutation,"aseq_"+str(flid)+"_"+orf+"_trbl_nn.txt")
								trbl_count+=1
							else:
								writetoFile(cdr_mutation,"aseq_"+str(flid)+"_"+orf+"_sub_nn.txt")
								cdr_sub_count+=1
								cdr_mut_count+=1
						#logger.debug("Stored NN mutations")
						cdr_del_name=namestore(cdr_del_count,"aseq_"+str(flid)+"_"+orf+"_del_nn.txt")
						if not cdr_del_name: cdr_del_name=""
						cdr_ins_name=namestore(cdr_ins_count,"aseq_"+str(flid)+"_"+orf+"_ins_nn.txt")
						if not cdr_ins_name: cdr_ins_name=""
						cdr_sub_name=namestore(cdr_sub_count,"aseq_"+str(flid)+"_"+orf+"_sub_nn.txt")
						if not cdr_sub_name: cdr_sub_name=""
						ins_rem=cdr_ins_count%3
						del_rem=cdr_del_count%3
						if cdr_ins_count>0:
							cdrrmrk=cdrrmrk+"INSERT;"
							if cdr_diff>=60:
								appendFiletoFile("CDR_nn.fasta","../data_"+phs+"/"+country+"/"+orf+"_nn_ins_err60.fasta")
							else:
								appendFiletoFile("CDR_nn.fasta","../data_"+phs+"/"+country+"/"+orf+"_nn_ins.fasta")
								appendFiletoFile("CDR_nn.fasta","../data_"+phs+"/CDR_seq/"+orf+"_nn_ins.fasta")
						else:
							if cdr_diff<=-60:
								appendFiletoFile("CDR_nn.fasta","../data_"+phs+"/"+country+"/"+orf+"_nn_err60.fasta")
							else:
								appendFiletoFile("CDR_nn.fasta","../data_"+phs+"/"+country+"/"+orf+"_nn.fasta")
								appendFiletoFile("CDR_nn.fasta","../data_"+phs+"/CDR_seq/"+orf+"_nn.fasta")
						writetoFile(country+","+fldt+","+str(flid)+","+orf+","+str(n_identity)+",NA;,"+str(cdr_sub_name)+str(cdr_del_name)+str(cdr_ins_name)+",NA;,"+cdrrmrk+","+tp+","+str(trbl_count), "aseq_"+str(flid)+"CDRmutinfo.csv") 
						#logger.debug("CDR files copied to Country/ID/")
				else:
					writetoFile(str(x)+","+str(flid)+","+country+","+orf+","+str(ncdr)+",NA;,"+str(cdr_count)+","+cdrrmrk, "../data_"+phs+"/excludeseq.csv")
					cncl="EXCL"
					logger.debug("cncl=EXCL")
	logger.debug("Handling aseq_"+str(flid)+"CDRmutinfo.csv")
	count_mut=0
	temporf=""
	cdr_cnl=""
	
	if os.path.exists("aseq_"+str(flid)+"CDRmutinfo.csv"):
		for line in open("aseq_"+str(flid)+"CDRmutinfo.csv"):
			count_mut+=1
			if re.findall(flid, line):
				contents_CDRmutinfo=line.split(",")
				temporf=contents_CDRmutinfo[3].split("_")
				orf_mut=temporf[1]
				if contents_CDRmutinfo[8]:
					cdr_cnl=str(orf_mut)+":"+str(contents_CDRmutinfo[8])
	name_mut=""
	for elem in pp_mutallnm:
		mutation_name=elem[2]+":"+elem[0]+str(elem[3])+elem[1]+";"
		name_mut=name_mut+mutation_name

	pp_combination_X=name_mut.replace("NA;","")
	pp_combination=removeX(pp_combination_X)
	mut_len=0
	mut_p_len=0
	mutation_count_nn=str(mutallnm).count(";")
	mutation_count_pp=str(pp_combination).count(";")

	if frgn=="ONE":
		if cncl=="INCL":
			if os.path.exists("../data_"+phs+"/unq_combn_lst.dat"):
				#logger.debug("UNQ_COMBN_LST exists")
				unq_combn_data=findinfo(mutallnm,"../data_"+phs+"/unq_combn_lst.dat")
				if unq_combn_data:
					if unq_combn_data[4]==mutallnm: 
						mut_len+=1
				pp_unq_combn_data=findinfo(pp_combination,"../data_"+phs+"/unq_combn_lst.dat")
				if pp_unq_combn_data:
					if pp_unq_combn_data[5]==pp_combination:
						mut_p_len+=1
			if mut_len==0:
				overwritetoFile(">"+country+"-"+cID+"-"+host+"-"+phs, "new_uniq_nn.fasta")
				writetoFile(inprog_seq_compl,"new_uniq_nn.fasta")
				appendFiletoFile("new_uniq_nn.fasta", "../data_"+phs+"/unqseq_file/unqseq_"+phs+"_nn.fasta")
				if mut_p_len==0:
					overwritetoFile(">"+country+"-"+cID+"-"+host+"-"+phs, "new_uniq_pp.fasta")
					writetoFile(grep_func(flid,"aseq_pp.fasta","","exl"),"new_uniq_pp.fasta") 
				
				if re.findall("INSERT",cdr_cnl):
					writetoFile(str(x)+","+str(flid)+","+country+","+phase+","+mutallnm+","+pp_combination+",INSERT", "../data_"+phs+"/unq_combn_lst.dat")
					if mut_p_len==0:
						appendFiletoFile("new_uniq_pp.fasta", "../data_"+phs+"/unqseq_file/unqseq_"+phs+"_pp_ins.fasta")
				else:
					writetoFile(str(x)+","+str(flid)+","+country+","+phase+","+mutallnm+","+pp_combination+",NORMAL", "../data_"+phs+"/unq_combn_lst.dat")
					if mut_p_len==0:
						appendFiletoFile("new_uniq_pp.fasta", "../data_"+phs+"/unqseq_file/unqseq_"+phs+"_pp.fasta")
					
			if mutallnm=="" and pp_combination=="":
				mut_count=0
				qry_identity=100.00
			else:
				mut_count=sub_count+del_count+ins_count
			writetoFile(cID+","+str(fldt)+","+str(subm_date)+","+continent+","+country+","+place+","+phase+","+str(nfreq)+" ("+str(nperc)+"%),"+str(qry_identity)+" ("+str(align_len)+"),"+str(mut_count)+" ("+str(sub_count)+"-"+str(del_count)+"-"+str(ins_count)+"),"+mutallnm+","+pp_combination+","+cdr_cnl+","+clade+","+gender+","+age+","+pango_lineage+","+str(mutation_count_pp)+","+str(mutation_count_nn)+","+host, "seq_combn_all_phs.csv")
		else:
			if mutallnm=="" and pp_combination=="":
				mut_count=0
				qry_identity=100.000
			else:
				mut_count=sub_count+del_count+ins_count
			writetoFile(cID+","+str(fldt)+","+str(subm_date)+","+continent+","+country+","+place+","+phase+","+str(nfreq)+" ("+str(nperc)+"%),"+str(qry_identity)+" ("+str(align_len)+"),"+str(mut_count)+" ("+str(sub_count)+"-"+str(del_count)+"-"+str(ins_count)+"),"+mutallnm+","+pp_combination+","+cdr_cnl+","+clade+","+gender+","+age+","+pango_lineage+","+str(mutation_count_pp)+","+str(mutation_count_nn)+","+host, "seq_combn_all_phs_one_excl.csv")
	else:
		if cncl=="INCL":
			writetoFile(cID+","+str(fldt)+","+str(subm_date)+","+continent+","+country+","+place+","+phase+","+str(nfreq)+" ("+str(nperc)+"%),"+str(qry_identity)+" ("+str(align_len)+"),"+mismatch+";"+str(mut_count)+" ("+str(sub_count)+"-"+str(del_count)+"-"+str(ins_count)+"),"+mutallnm+","+pp_combination+","+cdr_cnl+","+clade+","+gender+","+age+","+pango_lineage+","+str(mutation_count_pp)+","+str(mutation_count_nn)+","+host, "seq_combn_all_phs_mtpl_incl.csv")
		else:
			writetoFile(cID+","+str(fldt)+","+str(subm_date)+","+continent+","+country+","+place+","+phase+","+str(nfreq)+" ("+str(nperc)+"%),"+str(qry_identity)+" ("+str(align_len)+"),"+mismatch+";"+str(mut_count)+" ("+str(sub_count)+"-"+str(del_count)+"-"+str(ins_count)+"),"+mutallnm+","+pp_combination+","+cdr_cnl+","+clade+","+gender+","+age+","+pango_lineage+","+str(mutation_count_pp)+","+str(mutation_count_nn)+","+host, "seq_combn_all_phs_mtpl_excl.csv")

	writetoFile(str(x)+","+continent+","+country+","+place+","+str(fldt)+","+str(frgn)+","+cID+","+str(nfreq)+" ("+str(nperc)+"%),"+str(qry_identity)+" ("+str(align_len)+"),"+mismatch+";"+str(mut_count)+" ("+str(sub_count)+"-"+str(del_count)+"-"+str(ins_count)+"),"+mutallnm+","+pp_combination+","+cdr_cnl+","+cncl+","+rmrk+","+clade+","+gender+","+age+","+pango_lineage+","+str(mutation_count_pp)+","+str(mutation_count_nn)+","+host, "Summary_all.csv")

	os.system("mv *aseq* ../data_"+phs+"/"+country+"/"+str(flid)+"/")
	checkRemove("aanew.txt")
	checkRemove("tnew.txt")
	checkRemove("CDR_nn.fasta")
	checkRemove("CDR_pp.fasta")
	checkRemove("new_uniq_nn.fasta")
	checkRemove("new_uniq_pp.fasta")
	logger.debug("Generating newORF WG alignment and BLAST files")
	#os.system("makeblastdb	 -in uORF_nn_ref.fasta -dbtype nucl")
	os.system("blastn -query new.fasta -db uORF_nn_ref.fasta -outfmt 3 > aseq_nn_align_newORF.txt")
	os.system("blastn -query new.fasta -db uORF_nn_ref.fasta -outfmt 10 > aseq_nn_blast_newORF.out")
	
	for neworf, newpos in newORF.items():
		logger.debug("Starting analysis of "+str(neworf))
		cdrrmrk=""
		tempseq=""
		checkRemove("aanew_newORF.txt")
		checkRemove("aanew_pp_newORF.txt")
		cdr_count=sum(1 for elem in grep_func(neworf,"aseq_nn_blast_newORF.out","",""))
		blast_neworf=findinfo(neworf,"aseq_nn_blast_newORF.out")
		if not blast_neworf:
			writetoFile(str(x)+","+str(flid)+"_ERR: "+neworf+" BLAST Fail,"+str(cdr_count),"../data_"+phs+"/problem_seq_newORF.dat")
			logger.warning("BLAST Failed for "+str(neworf))
			continue
		start_pos=int(blast_neworf[6])
		start_space=start_pos-prend
		end_pos=int(blast_neworf[7])
		nmut=blast_neworf[4]
		prend=end_pos
		writetoFile("","aseq_nn_newORF.fsa")
		writetoFile(">aseq_"+country+"_"+str(flid)+"_"+neworf,"aseq_nn_newORF.fsa")
		overwritetoFile(">aseq_"+country+"_"+str(flid)+"_"+neworf, "CDR_nn_newORF.fasta")
		#logger.info("CDR count = "+str(cdr_count))
		if cdr_count==1:
			if end_pos>start_pos:
				overwritetoFile(inprog_seq_compl[start_pos-1:end_pos],"aanew_newORF.txt")
			else:
				overwritetoFile(inprog_seq_compl[end_pos-1:start_pos],"aanew_newORF.txt")
		else:
			writetoFile(str(x)+","+str(flid)+"_ERR: "+neworf+","+str(cdr_count),"../data_"+phs+"/problem_seq_newORF.dat")
		
		if not os.path.exists("aanew_newORF.txt"):
			logger.warning("aanew_newORF.txt NOT CREATED.")
			logger.debug("Moving to next newORF")
		else:
			#logger.debug("aanew_newORF.txt created and ORF region stored")
			cdr_len=len(readfromFile("aanew_newORF.txt"))
			cdr_diff=cdr_len-newpos[0]
			appendFiletoFile("aanew_newORF.txt","aseq_nn_newORF.fsa")
			appendFiletoFile("aanew_newORF.txt","CDR_nn_newORF.fasta")
			#logger.debug("CDR_nn_newORF.fasta created for "+str(neworf))
			if cdr_diff>0:
				if cdr_diff>=60:
					cdrrmrk="ERR_lngt_60("+str(cdr_diff)+");"
				else:
					cdrrmrk="Long("+str(cdr_diff)+");"
			elif cdr_diff<0:
				if cdr_diff<=-60:
					cdrrmrk="ERR_lngt_60("+str(cdr_diff)+");"
				else:
					cdrrmrk="Short("+str(cdr_diff)+");"

			writetoFile(str(flid)+","+neworf+","+str(newpos[0])+","+str(cdr_len)+","+str(cdr_diff),"aseq_"+str(flid)+"CDRcalc_newORF.csv")
			ncdr=readfromFile("aanew_newORF.txt").count("n")+readfromFile("aanew_newORF.txt").count("N")
			xfreq=0

			if neworf not in excep_newORF:
				tp="NOR"
				#logger.debug(str(neworf)+" not in exception")
				os.system("python3.6 translation_code.py")
				xfreq=readfromFile("aanew_pp_newORF.txt").count("x")+readfromFile("aanew_pp_newORF.txt").count("X")
				writetoFile("\n>aseq_pp_"+country+"_"+str(flid)+"_"+neworf,"aseq_pp_newORF.fasta")
				overwritetoFile(">aseq_pp_"+country+"_"+str(flid)+"_"+neworf,"CDR_pp_newORF.fasta")
				appendFiletoFile("aanew_pp_newORF.txt","aseq_pp_newORF.fasta")
				appendFiletoFile("aanew_pp_newORF.txt","CDR_pp_newORF.fasta")
				os.system("sed -i 's/0/X/g' aanew_pp_newORF.txt")

				if ncdr<=1 and cdr_count==1:
					#logger.debug("Performing BLASTn for "+str(neworf))
					#os.system("makeblastdb	 -in uref_nn/ref_"+neworf+"_nn.fasta -dbtype nucl")
					os.system("blastn -query CDR_nn_newORF.fasta -db uref_nn/ref_"+neworf+"_nn.fasta -outfmt 10 > aseq_nn_"+neworf+"_blast.out")
					os.system("blastn -query CDR_nn_newORF.fasta -db uref_nn/ref_"+neworf+"_nn.fasta -outfmt 3 > aseq_nn_"+neworf+"_align.txt")
					nblast_results=findinfo(flid,"aseq_nn_"+neworf+"_blast.out")
					if not nblast_results:
						writetoFile(str(x)+","+str(flid)+"_ERR: "+neworf+" nBLAST Fail,"+str(cdr_count),"../data_"+phs+"/problem_seq_newORF.dat")
						logger.warning("nBLAST Failed for "+str(neworf))
						continue
					n_identity=nblast_results[2]
					n_iden_cut=nblast_results[2].split(".")
					n_iden=n_iden_cut[0]
					nqon=int(nblast_results[6])
					nron=int(nblast_results[8])
					nmismatch=nblast_results[4]
					cdr_del_name=""
					cdr_ins_name=""
					cdr_sub_name=""
					pp_cdr_del_name=""
					pp_cdr_ins_name=""
					pp_cdr_sub_name=""
					cdr_mut_count=0
					cdr_ins_count=0
					cdr_del_count=0
					cdr_sub_count=0
					trbl_count=0
					if n_iden!=100:
						#logger.info("N_Identity != 100")					
						cdr_mut_position=mutposfunc("aseq_nn_"+neworf+"_align.txt", neworf, "nt")
						cdr_mut_position={int(k)+nron-1:v for k, v in cdr_mut_position.items()}
						if cdr_mut_position:
							temp_pp_muts=collectallmut(cdr_mut_position)
							mutallnm_newORF.extend(temp_pp_muts)
						for position_cdr, aa_cdr in cdr_mut_position.items():
							cdr_mutation=str(aa_cdr[0])+str(position_cdr)+str(aa_cdr[1]+";")
							if aa_cdr[0]=="-" and aa_cdr[1] in nts:
								writetoFile(cdr_mutation,"aseq_"+str(flid)+"_"+neworf+"_ins_nn.txt")
								cdr_ins_count+=1
								cdr_mut_count+=1
							elif aa_cdr[0]=="-" and aa_cdr[1] not in nts:
								writetoFile(cdr_mutation,"aseq_"+str(flid)+"_"+neworf+"_trbl_nn.txt")
							elif aa_cdr[0] in nts and aa_cdr[1]=="-":
								writetoFile(cdr_mutation,"aseq_"+str(flid)+"_"+neworf+"_del_nn.txt")
								cdr_del_count+=1
								cdr_mut_count+=1
							elif aa_cdr[0] in nts and aa_cdr[1] not in nts:
								writetoFile(cdr_mutation,"aseq_"+str(flid)+"_"+neworf+"_trbl_nn.txt")
							else:
								writetoFile(cdr_mutation,"aseq_"+str(flid)+"_"+neworf+"_sub_nn.txt")
								cdr_sub_count+=1
								cdr_mut_count+=1
						#logger.debug("Stored NN mutations")
						ins_rem=cdr_ins_count%3
						del_rem=cdr_del_count%3
						if ins_rem!=0 or del_rem!=0:
							tp="FMS"
						cdr_del_name=namestore(cdr_del_count,"aseq_"+str(flid)+"_"+neworf+"_del_nn.txt")
						if not cdr_del_name: cdr_del_name=""
						cdr_ins_name=namestore(cdr_ins_count,"aseq_"+str(flid)+"_"+neworf+"_ins_nn.txt")
						if not cdr_ins_name: cdr_ins_name=""
						cdr_sub_name=namestore(cdr_sub_count,"aseq_"+str(flid)+"_"+neworf+"_sub_nn.txt")
						if not cdr_sub_name: cdr_sub_name=""
						if cdr_ins_count>0:
							if cdr_diff>=60:
								appendFiletoFile("CDR_nn_newORF.fasta","../data_"+phs+"/"+country+"/newORF/"+neworf+"_nn_ins_err60.fasta")
								if tp=="FMS":
									continue
								else:
									appendFiletoFile("CDR_pp_newORF.fasta","../data_"+phs+"/"+country+"/newORF/"+neworf+"_pp_ins_err60.fasta")
							else:
								appendFiletoFile("CDR_nn_newORF.fasta","../data_"+phs+"/"+country+"/newORF/"+neworf+"_nn_ins.fasta")
								appendFiletoFile("CDR_nn_newORF.fasta","../data_"+phs+"/CDR_seq/newORF/"+neworf+"_nn_ins.fasta")
								if tp=="FMS":
									continue
								else:
									appendFiletoFile("CDR_pp_newORF.fasta","../data_"+phs+"/"+country+"/newORF/"+neworf+"_pp_ins.fasta")
									appendFiletoFile("CDR_pp_newORF.fasta","../data_"+phs+"/CDR_seq/newORF/"+neworf+"_pp_ins.fasta")
						else:
							if cdr_diff<=-60:
								appendFiletoFile("CDR_nn_newORF.fasta","../data_"+phs+"/"+country+"/newORF/"+neworf+"_nn_err60.fasta")
								if tp=="FMS":
									continue
								else:
									appendFiletoFile("CDR_pp_newORF.fasta","../data_"+phs+"/"+country+"/newORF/"+neworf+"_pp_err60.fasta")
							else:
								appendFiletoFile("CDR_nn_newORF.fasta","../data_"+phs+"/"+country+"/newORF/"+neworf+"_nn.fasta")
								appendFiletoFile("CDR_nn_newORF.fasta","../data_"+phs+"/CDR_seq/newORF/"+neworf+"_nn.fasta")
								if tp=="FMS":
									continue
								else:
									appendFiletoFile("CDR_pp_newORF.fasta","../data_"+phs+"/"+country+"/newORF/"+neworf+"_pp.fasta")
									appendFiletoFile("CDR_pp_newORF.fasta","../data_"+phs+"/CDR_seq/newORF/"+neworf+"_pp.fasta")
						#logger.debug("Copied NN fasta files to Country/ID folders")
						#logger.debug("Performing BLASTp for "+str(neworf))
						#os.system("makeblastdb	 -in uref_pp/ref_"+neworf+"_pp.fasta -dbtype prot")
						os.system("blastp -db uref_pp/ref_"+neworf+"_pp.fasta -query CDR_pp_newORF.fasta -outfmt 10 > aseq_pp_"+neworf+"_blast.out")
						os.system("blastp -db uref_pp/ref_"+neworf+"_pp.fasta -query CDR_pp_newORF.fasta -outfmt 3 > aseq_pp_"+neworf+"_align.txt")
						pblast_results=findinfo(flid,"aseq_pp_"+neworf+"_blast.out")
						if not pblast_results:
							writetoFile(str(x)+","+str(flid)+"_ERR: "+neworf+" pBLAST Fail,"+str(cdr_count),"../data_"+phs+"/problem_seq_newORF.dat")
							logger.warning("pBLAST Failed for "+str(neworf))
							continue
						p_identity=pblast_results[2]
						p_iden_cut=pblast_results[2].split(".")
						p_iden=p_iden_cut[0]
						p_qon=int(pblast_results[6])
						p_ron=int(pblast_results[8])
						p_mismatch=pblast_results[4]
						pp_sub_count=0
						pp_mut_count=0
						pp_ins_count=0
						pp_del_count=0
						pp_cdr_sub_name=""
						pp_cdr_del_name=""
						pp_cdr_ins_name=""
						if p_iden!=100:
							#logger.info("P_Identity != 100")
							temp_pp_muts=[]
							pp_mut_position=mutposfunc("aseq_pp_"+neworf+"_align.txt", neworf, "pt")
							pp_mut_position={int(k)+p_ron-1:v for k, v in pp_mut_position.items()}
							if pp_mut_position:
								temp_pp_muts=collectallmut(pp_mut_position)
								pp_mutallnm_newORF.extend(temp_pp_muts)
							for position_pp, aa_pp in pp_mut_position.items():
								pp_mutation=str(aa_pp[0])+str(position_pp)+str(aa_pp[1]+";")
								if aa_pp[0] not in pp_no:
									if aa_pp[1] not in pp_no:
										writetoFile(pp_mutation,"aseq_"+str(flid)+"_"+neworf+"_sub_pp.txt")
										pp_sub_count+=1
										pp_mut_count+=1
									elif aa_pp[1]=="-" :
										writetoFile(pp_mutation,"aseq_"+str(flid)+"_"+neworf+"_del_pp.txt")
										pp_del_count+=1
										pp_mut_count+=1
									else:
										writetoFile(pp_mutation,"aseq_"+str(flid)+"_"+neworf+"_trbl_pp.txt")
										trbl_count+=1
								elif aa_pp[0]=="-":
									writetoFile(pp_mutation,"aseq_"+str(flid)+"_"+neworf+"_ins_pp.txt")
									pp_ins_count+=1
									pp_mut_count+=1
								else:
									writetoFile(pp_mutation,"aseq_"+str(flid)+"_"+neworf+"_trbl_pp.txt")
									trbl_count+=1
							pp_cdr_sub_name=namestore(pp_sub_count,"aseq_"+str(flid)+"_"+neworf+"_sub_pp.txt")
							if not pp_cdr_sub_name: pp_cdr_sub_name=""
							pp_cdr_del_name=namestore(pp_del_count,"aseq_"+str(flid)+"_"+neworf+"_del_pp.txt")
							if not pp_cdr_del_name: pp_cdr_del_name=""
							pp_cdr_ins_name=namestore(pp_ins_count,"aseq_"+str(flid)+"_"+neworf+"_ins_pp.txt")
							if not pp_cdr_ins_name: pp_cdr_ins_name=""
							#logger.debug("Stored PP mutations")
							if pp_ins_count>0:
								cdrrmrk=cdrrmrk+"INSERT;"
							writetoFile(country+","+fldt+","+str(flid)+","+neworf+","+str(n_identity)+","+str(p_identity)+","+str(cdr_sub_name)+str(cdr_del_name)+str(cdr_ins_name)+","+str(pp_cdr_sub_name)+str(pp_cdr_del_name)+str(pp_cdr_ins_name)+","+cdrrmrk+","+tp+","+str(trbl_count), "aseq_"+str(flid)+"CDRmutinfo_newORF.csv")

						else:
							#logger.info("P_Identity = 100")
							trbl_count=sum(1 for line in open("aseq_"+str(flid)+"_"+neworf+"_trbl_nn.txt"))
							writetoFile(country+","+fldt+","+str(flid)+","+neworf+","+str(n_identity)+","+str(p_identity)+","+str(cdr_sub_name)+str(cdr_del_name)+str(cdr_ins_name)+",NA;,"+cdrrmrk+","+tp+","+str(trbl_count), "aseq_"+str(flid)+"CDRmutinfo_newORF.csv")

					else:
						#logger.info("N_identity = 100")
						if ins_rem!=0 or del_rem!=0:
							tp="FMS"
						if cdr_ins_count>0:
							cdrrmrk=cdrrmrk+"INSERT;"
							if cdr_diff>=60:
								appendFiletoFile("CDR_nn_newORF.fasta","../data_"+phs+"/"+country+"/newORF/"+neworf+"_nn_ins_err60.fasta")
								if tp=="FMS":
									continue
								else:
									appendFiletoFile("CDR_pp_newORF.fasta","../data_"+phs+"/"+country+"/newORF/"+neworf+"_pp_ins_err60.fasta")
							else:
								appendFiletoFile("CDR_nn_newORF.fasta","../data_"+phs+"/"+country+"/newORF/"+neworf+"_nn_ins.fasta")
								appendFiletoFile("CDR_nn_newORF.fasta","../data_"+phs+"/CDR_seq/newORF/"+neworf+"_nn_ins.fasta")
								if tp=="FMS":
									continue
								else:
									appendFiletoFile("CDR_pp_newORF.fasta","../data_"+phs+"/"+country+"/newORF/"+neworf+"_pp_ins.fasta")
									appendFiletoFile("CDR_pp_newORF.fasta","../data_"+phs+"/CDR_seq/newORF/"+neworf+"_pp_ins.fasta")
						else:
							if cdr_diff<=-60:
								appendFiletoFile("CDR_nn_newORF.fasta","../data_"+phs+"/"+country+"/newORF/"+neworf+"_nn_err60.fasta")
								if tp=="FMS":
									continue
								else:
									appendFiletoFile("CDR_pp_newORF.fasta","../data_"+phs+"/"+country+"/newORF/"+neworf+"_pp_err60.fasta")
							else:
								appendFiletoFile("CDR_nn_newORF.fasta","../data_"+phs+"/"+country+"/newORF/"+neworf+"_nn.fasta")
								appendFiletoFile("CDR_nn_newORF.fasta","../data_"+phs+"/CDR_seq/newORF/"+neworf+"_nn.fasta")
								if tp=="FMS":
									continue
								else:
									appendFiletoFile("CDR_pp_newORF.fasta","../data_"+phs+"/"+country+"/newORF/"+neworf+"_pp.fasta")
									appendFiletoFile("CDR_pp_newORF.fasta","../data_"+phs+"/CDR_seq/newORF/"+neworf+"_pp.fasta")
						trbl_count=0
						writetoFile(country+","+fldt+","+str(flid)+","+neworf+","+str(n_identity)+",100.000,NA;,NA;,"+cdrrmrk+","+tp+","+str(trbl_count), "aseq_"+str(flid)+"CDRmutinfo_newORF.csv")
						#logger.debug("Copied CDR_NN and CDR_PP files to Country/ID/")
				else:
					if xfreq!=0:
						writetoFile(str(x)+","+str(flid)+"_X_Freq: "+neworf+" = "+str(xfreq),"../data_"+phs+"/problem_seq.dat")
					writetoFile(str(x)+","+str(flid)+","+country+","+neworf+","+str(ncdr)+","+str(xfreq)+","+str(cdr_count)+","+cdrrmrk, "aseq_"+str(flid)+"excludeseq_newORF.csv")
					cncl="EXCL"
					logger.info("cncl=EXCL")
	logger.debug("Handling aseq_"+str(flid)+"CDRmutinfo_newORF.csv")
	count_mut=0
	tempneworf=""
	cdr_cnl=""
	pp_name_mut_newORF=""
	nn_name_mut_newORF=""
	if os.path.exists("aseq_"+str(flid)+"CDRmutinfo_newORF.csv"):
		for line in open("aseq_"+str(flid)+"CDRmutinfo_newORF.csv"):
			count_mut+=1
			if re.findall(flid, line):
				contents_CDRmutinfo_neworf=line.split(",")
				tempneworf=contents_CDRmutinfo_neworf[3].split("_")
				neworf_mut=tempneworf[1]
				if contents_CDRmutinfo_neworf[8]:
					cdr_cnl=str(neworf_mut)+":"+str(contents_CDRmutinfo_neworf[8])
	mutallnm_newORF=sorted(mutallnm_newORF, key=lambda x:(x[2],x[3]))
	pp_mutallnm_newORF=sorted(pp_mutallnm_newORF, key=lambda x:(x[2],x[3]))
	for elem in pp_mutallnm_newORF:
		pp_mutation_name=elem[2]+":"+elem[0]+str(elem[3])+elem[1]+";"
		pp_name_mut_newORF=pp_name_mut_newORF+pp_mutation_name
	for elem in mutallnm_newORF:
		nn_mutation_name=elem[2]+":"+elem[0]+str(elem[3])+elem[1]+";"
		nn_name_mut_newORF=nn_name_mut_newORF+nn_mutation_name

	nn_combination_newORF=nn_name_mut_newORF.replace("NA;","")
	nn_mutcount_newORF=nn_combination_newORF.count(":")
	pp_combination_newORF_X=pp_name_mut_newORF.replace("NA;","")
	pp_combination_newORF=removeX(pp_combination_newORF_X)
	pp_mutcount_newORF=pp_combination_newORF.count(":")
	mut_len=0
	mut_p_len=0
	if nn_combination_newORF:
		if os.path.exists("../data_"+phs+"/unq_combn_lst_newORF.dat"):
			unq_combn_data=grep_func(nn_combination_newORF,"../data_"+phs+"/unq_combn_lst_newORF.dat","","")
			for unq_data in unq_combn_data:
				unq_split=unq_data.split(",")
				if unq_split[4]==nn_combination_newORF and unq_split[5]==pp_combination_newORF:
					mut_len+=1

		if mut_len==0:		
			if re.findall("INSERT",cdr_cnl):
				writetoFile(str(x)+","+str(flid)+","+country+","+phase+","+nn_combination_newORF+","+pp_combination_newORF+",INSERT", "../data_"+phs+"/unq_combn_lst_newORF.dat")
			else:
				writetoFile(str(x)+","+str(flid)+","+country+","+phase+","+nn_combination_newORF+","+pp_combination_newORF+",NORMAL", "../data_"+phs+"/unq_combn_lst_newORF.dat")

		if frgn=="ONE":
			if cncl=="INCL":
				writetoFile(cID+","+str(fldt)+","+str(subm_date)+","+continent+","+country+","+place+","+phase+","+str(nfreq)+" ("+str(nperc)+"%),"+str(qry_identity)+" ("+str(align_len)+"),"+str(nn_mutcount_newORF)+" ("+str(pp_mutcount_newORF)+"),"+nn_combination_newORF+","+pp_combination_newORF+","+cdr_cnl+","+clade+","+gender+","+age+","+pango_lineage+","+str(pp_mutcount_newORF)+","+str(nn_mutcount_newORF)+","+host, "seq_combn_all_phs_newORF.csv")
			else:
				writetoFile(cID+","+str(fldt)+","+str(subm_date)+","+continent+","+country+","+place+","+phase+","+str(nfreq)+" ("+str(nperc)+"%),"+str(qry_identity)+" ("+str(align_len)+"),"+str(nn_mutcount_newORF)+" ("+str(pp_mutcount_newORF)+"),"+nn_combination_newORF+","+pp_combination_newORF+","+cdr_cnl+","+clade+","+gender+","+age+","+pango_lineage+","+str(pp_mutcount_newORF)+","+str(nn_mutcount_newORF)+","+host, "seq_combn_all_phs_one_excl_newORF.csv")
		else:
			if cncl=="INCL":
				writetoFile(cID+","+str(fldt)+","+str(subm_date)+","+continent+","+country+","+place+","+phase+","+str(nfreq)+" ("+str(nperc)+"%),"+str(qry_identity)+" ("+str(align_len)+"),"+str(nn_mutcount_newORF)+" ("+str(pp_mutcount_newORF)+"),"+nn_combination_newORF+","+pp_combination_newORF+","+cdr_cnl+","+clade+","+gender+","+age+","+pango_lineage+","+str(pp_mutcount_newORF)+","+str(nn_mutcount_newORF)+","+host, "seq_combn_all_phs_mltpl_incl_newORF.csv")
			else:
				writetoFile(cID+","+str(fldt)+","+str(subm_date)+","+continent+","+country+","+place+","+phase+","+str(nfreq)+" ("+str(nperc)+"%),"+str(qry_identity)+" ("+str(align_len)+"),"+str(nn_mutcount_newORF)+" ("+str(pp_mutcount_newORF)+"),"+nn_combination_newORF+","+pp_combination_newORF+","+cdr_cnl+","+clade+","+gender+","+age+","+pango_lineage+","+str(pp_mutcount_newORF)+","+str(nn_mutcount_newORF)+","+host, "seq_combn_all_phs_mltpl_excl_newORF.csv")

	writetoFile(str(x)+","+continent+","+country+","+place+","+str(fldt)+","+str(frgn)+","+cID+","+str(nfreq)+" ("+str(nperc)+"%),"+str(qry_identity)+" ("+str(align_len)+"),"+mismatch+";"+str(nn_mutcount_newORF)+" ("+str(pp_mutcount_newORF)+"),"+nn_combination_newORF+","+pp_combination_newORF+","+cdr_cnl+","+cncl+","+rmrk+","+clade+","+gender+","+age+","+pango_lineage+","+str(pp_mutcount_newORF)+","+str(nn_mutcount_newORF)+","+host, "Summary_all_newORF.csv")

	os.system("mv *aseq* ../data_"+phs+"/"+country+"/"+str(flid)+"/newORF/")
	checkRemove("aanew_newORF.txt")
	checkRemove("aanew_pp_newORF.txt")
	checkRemove("tnew.txt")
	checkRemove("CDR_nn_newORF.fasta")
	checkRemove("CDR_pp_newORF.fasta")

logger.debug("Processes completed.")

checkRemove("new.fasta")
checkRemove("new_uniq_nn_newORF.fasta")
checkRemove("new_uniq_pp_newORF.fasta")
logger.debug("Deleted database files and extras")
# End of script
end_time = datetime.datetime.now()
time_taken = end_time - start_time
write_time_func("Analysis_time.txt",end_time,2)
write_time_func("Analysis_time.txt",time_taken,0)
print ("\nTotal time taken is "+str(time_taken))
logger.debug("Stored End time")
logger.info("Total time - "+str(time_taken))
logger.debug("All Done.")

