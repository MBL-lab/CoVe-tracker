'''
	Author		-	L Ponoop Prasad Patro

	Program to translate genome sequence.
	Modified to store output in aanew_pp.txt

'''
#!/bin/python
import re
import os

cod={ "NNN":"X","NNT":"X","NNC":"X","NNA":"X","NNG":"X","NTN":"X","NCN":"X","NAN":"X","NGN":"X","NTT":"X","NTC":"X","NTA":"X","NTG":"X","NCT":"X","NCC":"X","NCA":"X","NCG":"X","NAT":"X","NAC":"X","NAA":"X","NAG":"X","NGT":"X","NGC":"X","NGA":"X","NGG":"X","TNN":"X","TNT":"X","TNC":"X","TNA":"X","TNG":"X","TTN":"X","TCN":"S","TAN":"X","TGN":"X","CNN":"X","CNT":"X","CNC":"X","CNA":"X","CNG":"X","CTN":"L","CCN":"P","CAN":"X","CGN":"R","ANN":"X","ANT":"X","ANC":"X","ANA":"X","ANG":"X","ATN":"X","ACN":"T","AAN":"X","AGN":"X","GNN":"X","GNT":"X","GNC":"X","GNA":"X","GNG":"X","GTN":"V","GCN":"A","GAN":"X","GGN":"G","TTA":"L","UUA":"L","TTR":"L","TTC":"F","UUC":"F","TTG":"L","UUG":"L","TTT":"F","UUU":"F","TTY":"F","TCT":"S","UCU":"S","TCA":"S","UCA":"S","TCG":"S","UCG":"S","TCC":"S","UCC":"S","TCR":"S","TCY":"S","TCW":"S","TCS":"S","TCM":"S","TCK":"S","TCH":"S","TCB":"S","TCV":"S","TCD":"S","TAT":"Y","UAU":"Y","TAC":"Y","UAC":"Y","TAY":"Y","TAA":"@","UAA":"@","TAG":"@","UAG":"@","TAR":"@","TGT":"C","UGU":"C","TGC":"C","UGC":"C","TGY":"C","TGA":"@","UGA":"@","TGG":"W","UGG":"W","CTT":"L","CUU":"L","CTA":"L","CUA":"L","CTC":"L","CUC":"L","CTG":"L","CUG":"L","CTR":"L","CTY":"L","CTW":"L","CTS":"L","CTM":"L","CTK":"L","CTH":"L","CTB":"L","CTV":"L","CTD":"L","CCT":"P","CCU":"P","CCA":"P","CCG":"P","CCC":"P","CCR":"P","CCY":"P","CCW":"P","CCS":"P","CCM":"P","CCK":"P","CCH":"P","CCB":"P","CCV":"P","CCD":"P","CAT":"H","CAU":"H","CAC":"H","CAY":"H","CAG":"Q","CAA":"Q","CAR":"Q","CGT":"R","CGU":"R","CGC":"R","CGA":"R","CGG":"R","CGR":"R","CGY":"R","CGW":"R","CGS":"R","CGM":"R","CGK":"R","CGH":"R","CGB":"R","CGV":"R","CGD":"R","ATT":"I","AUU":"I","ATC":"I","AUC":"I","ATA":"I","AUA":"I","ATH":"I","ATY":"I","ATM":"I","ATW":"I","ATG":"M","AUG":"M","ACT":"T","ACU":"T","ACA":"T","ACC":"T","ACG":"T","ACR":"T","ACY":"T","ACW":"T","ACS":"T","ACM":"T","ACK":"T","ACH":"T","ACB":"T","ACV":"T","ACD":"T","AAT":"N","AAU":"N","AAY":"N","AAC":"N","AAA":"K","AAG":"K","AAR":"K","AGT":"S","AGU":"S","AGC":"S","WGC":"S","WGT":"S","AGY":"S","WGY":"S","AGA":"R","AGG":"R","AGR":"R","MGA":"R","MGG":"R","MGR":"R","GTT":"V","GUU":"V","GTC":"V","GUC":"V","GTA":"V","GUA":"V","GTG":"V","GUG":"V","GTR":"V","GTY":"V","GTW":"V","GTS":"V","GTM":"V","GTK":"V","GTH":"V","GTB":"V","GTV":"V","GTD":"V","GCT":"A","GCU":"A","GCC":"A","GCA":"A","GCG":"A","GCR":"A","GCY":"A","GCW":"A","GCS":"A","GCM":"A","GCK":"A","GCH":"A","GCB":"A","GCV":"A","GCD":"A","GAT":"D","GAU":"D","GAC":"D","GAY":"D","GAA":"E","GAG":"E","GAR":"E","GGT":"G","GGU":"G","GGC":"G","GGA":"G","GGG":"G","GGR":"G","GGY":"G","GGW":"G","GGS":"G","GGM":"G","GGK":"G","GGH":"G","GGB":"G","GGV":"G","GGD":"G"}
cod.update(dict.fromkeys(['TYT','TRT','TWT','TST','TKT','TMT','TDT','TVT','THT','TBT','TTW','TTS','TTK','TTM','TTD','TTV','TTH','TTB','TAW','TAS','TAK','TAM','TAD','TAV','TAH','TAB','TGR','TGW','TGS','TGK','TGM','TGD','TGV','TGH','TGB'], 'X'))

cod_newORF={ "NNN":"X","NNT":"X","NNC":"X","NNA":"X","NNG":"X","NTN":"X","NCN":"X","NAN":"X","NGN":"X","NTT":"X","NTC":"X","NTA":"X","NTG":"X","NCT":"X","NCC":"X","NCA":"X","NCG":"X","NAT":"X","NAC":"X","NAA":"X","NAG":"X","NGT":"X","NGC":"X","NGA":"X","NGG":"X","TNN":"X","TNT":"X","TNC":"X","TNA":"X","TNG":"X","TTN":"X","TCN":"S","TAN":"X","TGN":"X","CNN":"X","CNT":"X","CNC":"X","CNA":"X","CNG":"X","CTN":"L","CCN":"P","CAN":"X","CGN":"R","ANN":"X","ANT":"X","ANC":"X","ANA":"X","ANG":"X","ATN":"X","ACN":"T","AAN":"X","AGN":"X","GNN":"X","GNT":"X","GNC":"X","GNA":"X","GNG":"X","GTN":"V","GCN":"A","GAN":"X","GGN":"G","TTA":"L","UUA":"L","TTR":"L","TTW":"X","TTC":"F","UUC":"F","TTG":"L","UUG":"L","TTT":"F","UUU":"F","TTY":"F","TCT":"S","UCU":"S","TCA":"S","UCA":"S","TCG":"S","UCG":"S","TCC":"S","UCC":"S","TCR":"S","TCY":"S","TCW":"S","TCS":"S","TCM":"S","TCK":"S","TCH":"S","TCB":"S","TCV":"S","TCD":"S","TAT":"Y","UAU":"Y","TAC":"Y","UAC":"Y","TAY":"Y","TAA":"*","UAA":"*","TAG":"*","UAG":"*","TAR":"*","TGT":"C","UGU":"C","TGC":"C","UGC":"C","TGY":"C","TGA":"*","UGA":"*","TGG":"W","UGG":"W","CTT":"L","CUU":"L","CTA":"L","CUA":"L","CTC":"L","CUC":"L","CTG":"L","CUG":"L","CTR":"L","CTY":"L","CTW":"L","CTS":"L","CTM":"L","CTK":"L","CTH":"L","CTB":"L","CTV":"L","CTD":"L","CCT":"P","CCU":"P","CCA":"P","CCG":"P","CCC":"P","CCR":"P","CCY":"P","CCW":"P","CCS":"P","CCM":"P","CCK":"P","CCH":"P","CCB":"P","CCV":"P","CCD":"P","CAT":"H","CAU":"H","CAC":"H","CAY":"H","CAG":"Q","CAA":"Q","CAR":"Q","CGT":"R","CGU":"R","CGC":"R","CGA":"R","CGG":"R","CGR":"R","CGY":"R","CGW":"R","CGS":"R","CGM":"R","CGK":"R","CGH":"R","CGB":"R","CGV":"R","CGD":"R","ATT":"I","AUU":"I","ATC":"I","AUC":"I","ATA":"I","AUA":"I","ATH":"I","ATY":"I","ATM":"I","ATW":"I","ATG":"M","AUG":"M","ACT":"T","ACU":"T","ACA":"T","ACC":"T","ACG":"T","ACR":"T","ACY":"T","ACW":"T","ACS":"T","ACM":"T","ACK":"T","ACH":"T","ACB":"T","ACV":"T","ACD":"T","AAT":"N","AAU":"N","AAY":"N","AAC":"N","AAA":"K","AAG":"K","AAR":"K","AGT":"S","AGU":"S","AGC":"S","WGC":"S","WGT":"S","AGY":"S","WGY":"S","AGA":"R","AGG":"R","AGR":"R","MGA":"R","MGG":"R","MGR":"R","GTT":"V","GUU":"V","GTC":"V","GUC":"V","GTA":"V","GUA":"V","GTG":"V","GUG":"V","GTR":"V","GTY":"V","GTW":"V","GTS":"V","GTM":"V","GTK":"V","GTH":"V","GTB":"V","GTV":"V","GTD":"V","GCT":"A","GCU":"A","GCC":"A","GCA":"A","GCG":"A","GCR":"A","GCY":"A","GCW":"A","GCS":"A","GCM":"A","GCK":"A","GCH":"A","GCB":"A","GCV":"A","GCD":"A","GAT":"D","GAU":"D","GAC":"D","GAY":"D","GAA":"E","GAG":"E","GAR":"E","GGT":"G","GGU":"G","GGC":"G","GGA":"G","GGG":"G","GGR":"G","GGY":"G","GGW":"G","GGS":"G","GGM":"G","GGK":"G","GGH":"G","GGB":"G","GGV":"G","GGD":"G"}
cod_newORF.update(dict.fromkeys(['TTS','TTK','TTM','TTD','TTV','TTH','TTB'], 'X'))

def trans(prot):
	pt=""

	for a in range(0,len(prot),3):
		c= prot[a:a+3]
		d= str(cod.get(c.upper(),0))
		pt=str(pt)+ str(d)
	pt=pt.split('@')
	pt=(max(pt, key=len))

	pt1=""
	for a in range(1,len(prot),3):
		c= prot[a:a+3]
		d= str(cod.get(c.upper(),0))
		pt1=str(pt1)+ str(d)
	pt1=pt1.split('@')
	pt1=(max(pt1, key=len))

	pt2=""
	for a in range(2,len(prot),3):
		c= prot[a:a+3]
		d= str(cod.get(c.upper(),0))
		pt2=str(pt2)+ str(d)
	pt2=pt2.split('@')
	pt2=(max(pt2, key=len))

	ptlst = [len(pt), len(pt1), len(pt2)]
	if (len(pt) == max(ptlst)):
		return(str(pt))
		#ps = str(pt)
	elif (len(pt1) == max(ptlst)):
		return(str(pt1))
		#ps = str(pt1)
	else:
		return(str(pt2))

def trans_newORF(prot):
	pt=""

	for a in range(0,len(prot),3):
		c= prot[a:a+3]
		d= str(cod_newORF.get(c.upper(),0))
		pt=str(pt)+ str(d)
	pt=pt.split('*')
	pt=(max(pt, key=len))
	return(str(pt))


if os.path.exists("aanew.txt"):
	p=open("aanew.txt","r").read()
	tr=trans(p)
	temp2=open("aanew_pp.txt","w")
	temp2.write(tr)
	temp2.close()
elif os.path.exists("aanew_newORF.txt"):
	p=open("aanew_newORF.txt","r").read()
	tr=trans_newORF(p)
	temp2=open("aanew_pp_newORF.txt","w")
	temp2.write(tr)
	temp2.close()
