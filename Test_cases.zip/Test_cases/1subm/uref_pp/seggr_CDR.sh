#!/bin/bash

sln=`wc -l nnlst_CDR.txt | awk '{print $1}'`
cn=`awk -F ',' '{print $1}' CDRmutinfo.csv | sort -u | wc -l`
for ((x=1; x<=$cn; x++))
do
    loctn=`awk -F ',' '{print $1}' CDRmutinfo.csv | sort -u | head -$x | tail -1`
    echo $loctn
    for ((i=1; i<=$sln; i++))
    do
        kw[$i]=`cat nnlst_CDR.txt | head -$i | tail -1`
	#echo ${kw[$i]}
    
	if [ "${kw[$i]}" != "UTR5_UTR5" ] && [ "${kw[$i]}" != "UTR3_UTR3" ] && [ "${kw[$i]}" != "ORF1ab_stemloop1" ] && [ "${kw[$i]}" != "ORF1ab_stemloop2" ] && [ "${kw[$i]}" != "ORF10_stemloop1" ] && [ "${kw[$i]}" != "ORF10_stemloop2" ]
	then
	    echo "CDR: "${kw[$i]} >> $loctn"_mutation_cnt.csv"
	    mutcnt=`grep -i $loctn CDRmutinfo.csv | grep -i ${kw[$i]} | grep -vi "insert" | awk -F ',' '{print $8}' | tr ';' '\n' | grep . | sort -u | wc -l`
	    if [ $mutcnt -gt 0 ]
	    then
		for ((j=1; j<=$mutcnt; j++))
		do
		    mutnm=`grep -i $loctn CDRmutinfo.csv | grep -i ${kw[$i]} | grep -vi "insert" | awk -F ',' '{print $8}' | tr ';' '\n' | grep . | sort -u | head -$j | tail -1`
		    cntmutnm=`grep -i $loctn CDRmutinfo.csv | grep -i ${kw[$i]} | grep -vi "insert" | grep -i $mutnm";" | wc -l`

		    if [ $cntmutnm -gt 0 ]
		    then
			#cdrcnt=`grep -i "^>" $loctn/`
			echo $mutnm","$cntmutnm >> $loctn"_mutation_cnt.csv"
		    fi
		done
	    fi
	    delcnt=`grep -i $loctn CDRmutinfo.csv | grep -i ${kw[$i]} | grep -vi "insert" | awk -F ',' '{print $12}' | tr ';' '\n' | grep . | sort -u | wc -l`
	    if [ $delcnt -gt 0 ]
            then
                for ((j=1; j<=$delcnt; j++))
                do
                    mutnm=`grep -i $loctn CDRmutinfo.csv | grep -i ${kw[$i]} | grep -vi "insert" | awk -F ',' '{print $12}' | tr ';' '\n' | grep . | sort -u | head -$j | tail -1`
                    cntmutnm=`grep -i $loctn CDRmutinfo.csv | grep -i ${kw[$i]} | grep -vi "insert" | grep -i $mutnm";" | wc -l`
		    
                    if [ $cntmutnm -gt 0 ]
                    then
                        #cdrcnt=`grep -i "^>" $loctn/`
                        echo $mutnm","$cntmutnm >> $loctn"_mutation_cnt.csv"
                    fi
                done
            fi
	fi
    done
done
