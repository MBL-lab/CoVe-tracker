#!/bin/bash

#    Author    -    Murali Aadhitya M S
#    Created   -    11 Dec 2021 09:11:00

# Script to sort out all unq_seq files from data folders
mkdir Unq_seq_phylo
temp3=$1
temp4=`echo "../Compiled_Unq_Seq_"$temp3".fasta"`
ls | grep "data" > data_folders.txt

while read -a folder; do
    if [ -d $folder ] ; then
#	echo folder $folder
	temp=$folder"/unqseq_file/*_pp.fasta"
#	echo temp $temp
	cp $temp Unq_seq_phylo/
    fi
    
done < data_folders.txt
rm data_folders.txt
cd Unq_seq_phylo

ls | grep "nn.fasta" | cut -d'_' -f2 > Monthlist.txt

while read -a file; do
    temp2=`ls | grep $file`
#    echo -e "\n temp2 "$temp2
    sed -i "/^>/ s/$/_${file}_${temp3}/g" $temp2
    cat $temp2 >> $temp4
done < Monthlist.txt
rm Monthlist.txt
echo -e "\n\tDone Compiling.\n"
