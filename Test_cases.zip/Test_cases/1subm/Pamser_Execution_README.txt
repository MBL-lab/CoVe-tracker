'''
	Author		-	Murali Aadhitya M S
	Created		-	Fri Dec 24 12:20:09 IST 2021
	Modified	-	Fri Dec 24 12:20:09 IST 2021

'''


Files and Folders Required:
	> Python_files_with_db_5 : 27 Items (4 Folders; 23 Files)
	> Essntials_Pamser : 13 Items (13 Files)


Steps:							
1	Download sequences from GISAID						
2a	For one sequence file 	-	Run formatfasta.sh on sequence file			./formatfasta.sh (Seq_File)
2b	For Multiple files	-	Run fileformatter.py inside sequences folder		python3.6 fileformatter.py
3	Backup Sequences into tar file and copy to HDD						nohup tar -zcvf (Month_Sequences.tar.gz) (Month_Sequences Folder) > tar_(Month).out &
4	Download Metadata from Gisaid						
5	Extract Metadata						
6	Change .tsv file to .csv								cat (filename.tsv) | tr ',' ';' | tr '\t' ',' > (output_filename.csv)
7	Check titles of Metadata.csv								awk -F ',' '{print NF}' metadata_1Jul2021.csv | sort -u
												head -1 metadata_1Jul2021.csv
8	Copy Python_files_with_db_5 folder to MONTH folder						
9	Copy the following Essential_Pamser files to MONTH folder :	
		auto_subm.sh					
		metafilter.sh					
		formatfasta.sh					
		splitseq.py					
		covid_directory_delete.sh					
		result_compiler_v2.py					
		unq_file_collector.sh					
10	Change permission to executable for .sh files						chmod 700 *.sh
11	Create DATE_MONTH Folder												
12	Run Metafilter.sh inside DATE_MONTH Folder				3 Arguments	./../metafilter.sh (Seq_File_Path) (Overall_Metafile_Path) (Date_of_Sequences)
13	Create 'seqs' folder						
14	Run splitseq.py inside seqs folder					3 Arguments	python3.6 ../splitseq.py (Seq_File_Path) (Date_of_Sequences) (No._of_Seqs_per_File)
15	Verify the number of seqs (total) to the original file						
16	Inside DATE_MONTH folder, run auto_subm.sh				5 Arguments	./../auto_subm.sh (Path_to_Py_files) (Path_of_seqs_foder) (Path_to_Metadata_file) (Start_Job) (End_Job)
17	Let it finish; Take proper rest and Sleep till then						
18	Confirm end of all jobs		
19	run result_compiler.py									python3.6 ../result_compiler.py
20	Delete 'seqs' folder						
21	Check number of lines in seq_combn and Summary files					wc *
22	Remove subm folders						
23	Take backup of complete DATE_MONTH folder						nohup tar -zcvf (DATE_MONTH.tar.gz) (DATE_MONTH Folder) > tar_(DATE_MONTH).out &
24	Move tar backup file to HDD						
25	Run covid_directory_delete.sh inside DATE_MONTH folder(Removes all ID Folder)		nohup ./../covid_directory_delete.sh >> ../del(DATE_MONTH).out &
							

							
	> Check Job Status			grep "SL:" *bm/Pro* | wc				
	> Total sequences 			wc Metadata_(DATE_MONTH).csv
	> Check Time taken for completion	grep "Time" *bm/Ana* | wc