'''
	Author		:	Murali Aadhitya M S
	Created on 	:	Thu Dec  2 17:22:03 IST 2021

	> This code is to compile all results from individual submission folders.
	> Run only after all jobs are completed.
	> V2 - Compiles Time taken from Analysis_time.txt
'''
import os
files=[]
command_filelist="ls | grep ""subm"" | sort -g > filelist.txt"
os.system(command_filelist)
list=open("filelist.txt","r", encoding="utf-8")
files=list.read().split()
list.close()
#print(files)
print("Total subm files found = "+str(len(files)))
filename=["seq_combn_all_phs.csv", "seq_combn_all_phs_one_excl.csv", "seq_combn_all_phs_mtpl_incl.csv", "seq_combn_all_phs_mtpl_excl.csv", "seq_combn_all_phs_newORF.csv", "seq_combn_all_phs_one_excl_newORF.csv", "seq_combn_all_phs_mltpl_incl_newORF.csv", "seq_combn_all_phs_mltpl_excl_newORF.csv", "Summary_all.csv", "Summary_all_newORF.csv"]
for csvfile in filename:
	for folder in files:
		temp1=str(folder)+"/"+str(csvfile)
		cmd="cat "+str(temp1)+" >> "+str(csvfile)
		if os.path.exists(temp1):
			os.system(cmd)
	print("Done compiling "+str(csvfile))
os.remove("filelist.txt")
#os.system("rm -r *subm") 		#Better to remove folders manually

command_time="grep \"Time\" *bm/Ana* | sort -g | sed 's/\/Analysis_time.txt:Time taken : /;/g' >> Time_compiled.txt"
os.system(command_time)
