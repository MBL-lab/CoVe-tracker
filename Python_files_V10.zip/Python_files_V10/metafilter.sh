#!/bin/bash

#	Author		-	Murali Aadhitya M S
#	Created on	-	27 ?November ?2021, ??12:23:48

#	Program to filter out metadata info of sequences ready for analysis

seqfile=$1
metafile=$2
date=$3
echo ""
echo "seqfile" $seqfile
echo "metafile" $metafile

grep ">" $seqfile | cut -d "|" -f2 > seqlist.txt
grep -IFf seqlist.txt $metafile > Metadata_$date.csv
a=`wc -l seqlist.txt | cut -d' ' -f1`
b=`wc -l Metadata_$date.csv | cut -d' ' -f1`
echo "The number of lines of sequences are "$a
echo "The number of lines in Metadata are "$b
if [ $a -ne $b ]
then
	cut -d',' -f3 Metadata_$date.csv > metacross.txt
	echo -e "\nThe metadata values were not found for the following IDs:\n"
	echo -e "\nThe metadata values were not found for the following IDs:\n" > Exceptions_Metadata.txt
	grep -vFf metacross.txt seqlist.txt
	grep -vFf metacross.txt seqlist.txt >> Exceptions_Metadata.txt
	echo ""
	echo "Count = "$a-$b | bc
	rm metacross.txt
fi 
echo -e "\nDone.\n"
rm seqlist.txt