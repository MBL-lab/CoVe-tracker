#!/bin/bash

start_time=`date +%s`
echo "Start_time: "$start_time >> analyses_time_fltrns.txt

flnm="apr30"
addr="apr08"

cat $flnm/Seqlst.txt >> $addr/Seqlst.txt
echo $flnm >> $addr/analyses_time.txt
cat $flnm/analyses_time.txt >> $addr/analyses_time.txt

cat $flnm/unqseq_phyl/unqseq_Apr_pp_ins.fasta >> $addr/unqseq_phyl/unqseq_Apr_pp_ins.fasta

nseq=`grep -i "^>" $flnm/unqseq_phyl/unqseq_Apr_nn.fasta | wc -l`
npseq=`grep -i "^>" $flnm/unqseq_phyl/unqseq_Apr_pp.fasta | wc -l`
for ((x=1; x<=$nseq; x++))
do
    fhd=`grep -i "^>" $flnm/unqseq_phyl/unqseq_Apr_nn.fasta | head -$x | tail -1`
    flid=`echo $fhd | awk -F 'EPI_ISL_' '{print $2}' | tr -d '\r'`
    mutallnm=`awk -F ',' -v id=$flid '{if ($2 == id){print $5}}' $flnm/unq_combn_lst.dat`
    ppcombtn=`awk -F ',' -v id=$flid '{if ($2 == id){print $6}}' $flnm/unq_combn_lst.dat`
    cdrcnl=`awk -F ',' -v id=$flid '{if ($2 == id){print $7}}' $flnm/unq_combn_lst.dat | tr -d "\r"`
    
    mutln=`awk -F ',' -v nn=$mutallnm -v pp=$ppcombtn '{if (($5 == nn) && ($6 == pp)){print $2}}' $addr/unq_combn_lst.dat | wc -l`
    if [ $mutln -eq 0 ]
    then
	mutpln=`awk -F ',' -v pp=$ppcombtn '{if ($6 == pp){print $2}}' $addr/unq_combn_lst.dat | wc -l`
	awk -F ',' -v id=$flid '{if ($2 == id){print $0}}' $flnm/unq_combn_lst.dat >> $addr/unq_combn_lst.dat
	if [ $x -ne $nseq ]
	then
            j=`echo $x + 1 | bc`
	    shd=`grep -i "^>" $flnm/unqseq_phyl/unqseq_Apr_nn.fasta | head -$j | tail -1`

	    sed -nr '/'$fhd'/,/'$shd'/p' $flnm/unqseq_phyl/unqseq_Apr_nn.fasta | head -n -1 | head -1 >> $addr/unqseq_phyl/unqseq_Apr_nn.fasta
	    sed -nr '/'$fhd'/,/'$shd'/p' $flnm/unqseq_phyl/unqseq_Apr_nn.fasta | head -n -1 | tail -n +2 | tr -d "-" | tr -d "\n\r" >> $addr/unqseq_phyl/unqseq_Apr_nn.fasta
	    echo "" >> $addr/unqseq_phyl/unqseq_Apr_nn.fasta
	else
	    sed -nr '/'$fhd'/,$ p' $flnm/unqseq_phyl/unqseq_Apr_nn.fasta | head -1 >> $addr/unqseq_phyl/unqseq_Apr_nn.fasta
            sed -nr '/'$fhd'/,$ p' $flnm/unqseq_phyl/unqseq_Apr_nn.fasta | tail -n +2 | tr -d "-" | tr -d "\n\r" >> $addr/unqseq_phyl/unqseq_Apr_nn.fasta
	    echo "" >> $addr/unqseq_phyl/unqseq_Apr_nn.fasta
	fi

	if [ $mutpln -eq 0 ] && [ $cdrcnl != "INSERT" ]
	then
	    xx=`grep -i ">" $flnm/unqseq_phyl/unqseq_Apr_pp.fasta | grep -in "EPI_ISL_"$flid | cut -d ":" -f1`
	    if [ -z $xx ]
	    then
		continue
	    else
		fhdp=`grep -i "^>" $flnm/unqseq_phyl/unqseq_Apr_pp.fasta | head -$xx | tail -1`
		if [ $xx -ne $npseq ]
		then
		    jj=`echo $xx + 1 | bc`
		    shdp=`grep -i "^>" $flnm/unqseq_phyl/unqseq_Apr_pp.fasta | head -$jj | tail -1`
		    
		    sed -nr '/'$fhdp'/,/'$shdp'/p' $flnm/unqseq_phyl/unqseq_Apr_pp.fasta | head -n -1 | head -1 >> $addr/unqseq_phyl/unqseq_Apr_pp.fasta
		    sed -nr '/'$fhdp'/,/'$shdp'/p' $flnm/unqseq_phyl/unqseq_Apr_pp.fasta | head -n -1 | tail -n +2 | tr -d "-" | tr -d "\n\r" >> $addr/unqseq_phyl/unqseq_Apr_pp.fasta
		    echo "" >> $addr/unqseq_phyl/unqseq_Apr_pp.fasta
		else
		    sed -nr '/'$fhdp'/,$ p' $flnm/unqseq_phyl/unqseq_Apr_pp.fasta | head -1 >> $addr/unqseq_phyl/unqseq_Apr_pp.fasta
		    sed -nr '/'$fhdp'/,$ p' $flnm/unqseq_phyl/unqseq_Apr_pp.fasta | tail -n +2 | tr -d "-" | tr -d "\n\r" >> $addr/unqseq_phyl/unqseq_Apr_pp.fasta
		    echo "" >> $addr/unqseq_phyl/unqseq_Apr_pp.fasta
		fi
	    fi
	fi
    fi
    #cat $flnm/csvfl >> $addr/csvfl
done

nseq=`wc -l $flnm/unq_combn_lst_newORF.dat | awk '{print $1}'`

for ((x=1; x<=$nseq; x++))
do
    mutallnm=`head -$x $flnm/unq_combn_lst_newORF.dat | tail -1 | awk -F ',' '{print $5}'`
    ppcombtn=`head -$x $flnm/unq_combn_lst_newORF.dat | tail -1 | awk -F ',' '{print $6}'`
    mutln=`awk -F ',' -v nn=$mutallnm -v pp=$ppcombtn '{if (($5 == nn) && ($6 == pp)){print $2}}' $addr/unq_combn_lst_newORF.dat | wc -l`
    if [ $mutln -eq 0 ]
    then
	head -$x $flnm/unq_combn_lst_newORF.dat | tail -1 >> $addr/unq_combn_lst_newORF.dat
    fi
done

cn=`ls $flnm/*.csv | wc -l`
for ((i=1; i<=$cn; i++))
do
    csvfl=`ls $flnm/*.csv | head -$i | tail -1 | cut -d "/" -f2`
    cat $flnm/$csvfl >> $addr/$csvfl
done

dtn=`ls $flnm/prblm_seq*.dat | wc -l`
for ((i=1; i<=$dtn; i++))
do
    dtfl=`ls $flnm/prblm_seq*.dat | head -$i | tail -1 | cut -d "/" -f2`
    cat $flnm/$dtfl >> $addr/$dtfl
done


dn=`ls -d $flnm/*/ | grep -vi "ref_" | grep -vi "uref_" | grep -vi "unqseq_phyl" | grep -vi "CDR_seq" | wc -l`
for ((j=1; j<=$dn; j++))
do
    drnm=`ls -d $flnm/*/ | grep -vi "ref_" | grep -vi "uref_" | grep -vi "unqseq_phyl" | grep -vi "CDR_seq" | head -$j | tail -1`
    cntry=`echo $drnm | cut -d "/" -f2`
    
    fileDir="$addr/$cntry"
    if [ ! -d "$fileDir" ]; then 
	mkdir "$fileDir"
	mkdir "$fileDir/newORF"
    fi
    
    sdn=`ls -d $drnm*/ | grep -vi "newORF" | wc -l`
    for ((k=1; k<=$sdn; k++))
    do
	sdrnm=`ls -d $drnm*/ | grep -vi "newORF" | head -$k | tail -1`
	mv $sdrnm $fileDir/
    done

    cdrn=`ls $drnm"newORF"/*.fasta | wc -l`
    for ((z=1; z<=$cdrn; z++))
    do
        cdrnm=`ls $drnm"newORF"/*.fasta | head -$z | tail -1 | cut -d "/" -f4`
        cat $drnm"newORF"/$cdrnm >> $fileDir/newORF/$cdrnm
    done

    cdrn=`ls $drnm*.fasta | wc -l`
    for ((z=1; z<=$cdrn; z++))
    do
	cdrnm=`ls $drnm*.fasta | head -$z | tail -1 | cut -d "/" -f3`
	cat $drnm$cdrnm >> $fileDir/$cdrnm
    done
done

end_time=`date +%s`
echo "Time taken:" >> analyses_time_fltrns.txt
echo $end_time - $start_time | bc >> analyses_time_fltrns.txt
