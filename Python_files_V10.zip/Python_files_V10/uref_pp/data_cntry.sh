#!/bin/bash

sln=`cat CDR_lst.txt | wc -l`

for ((i=1; i<=2; i++))
do
    cdrnm=`cat CDR_lst.txt | head -$i | tail -1`
    j=`echo $i + 1 | bc`
    nxtcdr=`cat CDR_lst.txt | head -$j | tail -1`

    if [ $i -ne $sln ]
    then
    
	sed -n '/'$cdrnm'/,/'$nxtcdr'/p' *cnt.csv | grep -v "CDR:" | awk -F "," 'a=$1, b=gsub(/[^0-9]/,"",$1)''{print $1,a,$2}' | sort -nk1 | awk '{print $1,$2}' | uniq > $cdrnm"_mutpstn.txt"
	mutcnt=`sed -n '/'$cdrnm'/,/'$nxtcdr'/p' *cnt.csv | grep -v "CDR:" | awk -F "," 'a=$1, b=gsub(/[^0-9]/,"",$1)''{print $1,a,$2}' | sort -nk1 | awk '{print $1,$2}' | uniq | wc -l`
    else
	sed -n '/'$cdrnm'/,$ p' *cnt.csv | grep -v "CDR:" | awk -F "," 'a=$1, b=gsub(/[^0-9]/,"",$1)''{print $1,a,$2}' | sort -nk1 | awk '{print $1,$2}' | uniq > $cdrnm"_mutpstn.txt"
        mutcnt=`sed -n '/'$cdrnm'/,$ p' *cnt.csv | grep -v "CDR:" | awk -F "," 'a=$1, b=gsub(/[^0-9]/,"",$1)''{print $1,a,$2}' | sort -nk1 | awk '{print $1,$2}' | uniq | wc -l`
    fi
    cntrylst=`cat country_order.txt | wc -l`
    cntrynms=`cat country_order.txt | tr -d '\r' | tr '\n' ','`
    echo ",,"$cntrynms > $cdrnm"_world.csv"
    echo "" >> $cdrnm"_world.csv"
    for ((x=1; x<=$mutcnt; x++))
    do
	mutnm=`cat $cdrnm"_mutpstn.txt" | head -$x | tail -1 | awk '{print $2}'`
	mutp=`cat $cdrnm"_mutpstn.txt" | head -$x | tail -1 | awk '{print $1}'`
	echo -n $mutp","$mutnm"," >> $cdrnm"_world.csv"
	for ((y=1; y<=$cntrylst; y++))
	do
	    
	    cntry=`cat country_order.txt | head -$y | tail -1`
	    #echo $cntry
	    flnm=`ls *cnt.csv | grep -i $cntry`
	    if [ -z "$flnm" ]
	    then
		echo -n "0," >> $cdrnm"_world.csv" 
	    else
		#echo $flnm
		if [ $i -ne $sln ]
		then
		    frq=`sed -n '/'$cdrnm'/,/'$nxtcdr'/p' $flnm | grep -v "CDR:" | awk -F "," -v mutnm=$mutnm '{if ($1 == mutnm){print $2","}}'`
		else
		    frq=`sed -n '/'$cdrnm'/,$ p' $flnm | grep -v "CDR:" | awk -F "," -v mutnm=$mutnm '{if ($1 == mutnm){print $2","}}'`
		fi
	    if [ -z "$frq" ]
	    then
		echo -n "0," >> $cdrnm"_world.csv"
	    else
		echo -n $frq >> $cdrnm"_world.csv"
	    fi
	    fi
	done
	echo "" >> $cdrnm"_world.csv"
    done
    
done
