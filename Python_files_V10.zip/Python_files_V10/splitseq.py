'''
	Author		-	Murali Aadhitya M S
	Date Created	-	27 November 2021, 12:23:48

	Program to split sequences into subfiles of sepecific seq count.

'''

import os
import re
import sys
def readfromFile(filename_readfrom):
	file = open(filename_readfrom,"r")
	line = file.read().replace("\n", "")
	file.close()
	return line
def formatfasta(inputfile_formatfasta):
	#This function calls an external script to modify the contents of the sequence input file.
	# The external script is a bash script that replaces all \n and \r in the seq file.
	cmd_format="./formatfasta.sh "+str(inputfile_formatfasta)
	os.system("chmod 700 formatfasta.sh")
	os.system(cmd_format)
#z=2000 #Change value to specify the number of sequences. 100 sequences means z=200; 1000 seq => z=2000
seqfile=sys.argv[1]
gisaiddate=sys.argv[2]
z=int(sys.argv[3])*2
#formatfasta(seqfile)
contents=readfromFile(seqfile)
numseq=contents.count(">")
print("\nThe number of sequences are "+str(numseq))
print("Splitting into files with "+str(int(z/2))+" sequences.")
y=1

with open(seqfile) as fileinprog:
	data=fileinprog.readlines()
	for x in range(0,numseq*2,z):
		newfile=open(str(y)+"_gisaid_seq_"+str(gisaiddate)+".fasta", "w+")
		newfile.writelines(data[x:x+z])
		print(str(y)+" File created.")
		y+=1
		newfile.close()
print("\nAll files created.\n")

