tring = ">Hello"
print(tring)
print(tring.replace(">",""))
valu=tring.replace(">","")
print(valu)
