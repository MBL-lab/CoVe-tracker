#!/bin/bash
flnm="uORF_nn_ref.fasta"

kw=("COV2_1a_uORF1_ext" "COV2_1a_uORF1_0" "COV2_1a_uORF2_ext" "COV2_1a_uORF2_0" "COV2_1a_iORF" "COV2_S_iORF1" "COV2_S_iORF2" "COV2_3a_iORF1_ORF3c" "COV2_3a_iORF2" "COV2_E_iORF" "COV2_M_ext" "COV2_M_iORF" "COV2_6_iORF" "COV2_7a_iORF1" "COV2_7a_iORF2" "COV2_7a_iORF3" "COV2_7b_iORF1" "COV2_7b_iORF2" "COV2_8_iORF" "COV2_N_iORF1_ORF9b" "COV2_N_iORF2" "COV2_10_uORF" "COV2_10_iORF")

grep -i "^>" $flnm > Seqlst.txt

nfl=`wc -l Seqlst.txt | awk '{print $1}'`

for ((i=1; i<=$nfl; i++))
do
    seqhd=`head -$i Seqlst.txt | tail -1`
    flid=`echo $seqhd | awk -F '>COV2_' '{print $2}'`
    x=`echo $i - 1 | bc`
    cdrflnm="ref_"${kw[$x]}"_nn.fasta"
    
    if [ -z "$seqhd" ]
    then
        echo $i","$seqhd >> err_seq_head.csv
    fi

    
    if [ $i -ne $nfl ]
    then
        j=`echo $i + 1 | bc`
        sseqhd=`head -$j Seqlst.txt | tail -1`
        
        ncnt=`sed -nr "/'$seqhd'/,/'$sseqhd'/p" $flnm | sed -e '1d;$d' | tr -d " \n" | wc -m`
        if [ $ncnt -ne 0 ]
        then
            sed -nr "/'$seqhd'/,/'$sseqhd'/p" $flnm | head -n -1 | head -1 > new.fasta
            sed -nr "/'$seqhd'/,/'$sseqhd'/p" $flnm | head -n -1 | tail -n +2 | tr -d "-" | tr -d "\n\r" >> new.fasta
        else
	    ncnt=`sed -nr '/'$seqhd'/,/'$sseqhd'/p' $flnm | sed -e '1d;$d' | tr -d " \n" | wc -m`
            sed -nr '/'$seqhd'/,/'$sseqhd'/p' $flnm | head -n -1 | head -1 > new.fasta
            sed -nr '/'$seqhd'/,/'$sseqhd'/p' $flnm | head -n -1 | tail -n +2 | tr -d "-" | tr -d "\n\r" >> new.fasta
        fi
    else
        ncnt=`sed -nr "/'$seqhd'/,$ p" $flnm | tail -n +2 | tr -d " \n" | wc -m`
        snx=0
        if [ $ncnt -ne 0 ]
	then
            sed -nr "/'$seqhd'/,$ p" $flnm | head -1 > new.fasta
            sed -nr "/'$seqhd'/,$ p" $flnm | tail -n +2 | tr -d "-" | tr -d "\n\r" >> new.fasta
        else
	    ncnt=`sed -nr '/'$seqhd'/,$ p' $flnm | tail -n +2 | tr -d " \n" | wc -m`
            sed -nr '/'$seqhd'/,$ p' $flnm | head -1 > new.fasta
            sed -nr '/'$seqhd'/,$ p' $flnm | tail -n +2 | tr -d "-" | tr -d "\n\r" >> new.fasta
        fi
    fi
    cat new.fasta >> $cdrflnm
        
    echo $i","$flid","$ncnt >> newCDR_cnt.csv
done
