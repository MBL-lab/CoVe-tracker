#!/bin/bash
n=`ls -d data_*/ | wc -l`
ls -d data_*/ > fllst1
pth1=`pwd`
echo $pth1
echo "################"
for ((i=1; i<=$n; i++))
do
drnm=`head -$i fllst1 | tail -1`
pth2=$pth1"/"$drnm
cd $drnm
echo $i"::"$pth2
echo "=============="
m=`ls -d */ | grep -vi "CDR_seq" | grep -vi "unqseq_phyl" | wc -l`

for ((j=1; j<=$m; j++))
do
 cntry=`ls -d */ | grep -vi "CDR_seq" | grep -vi "unqseq_phyl" | head -$j | tail -1`
 pth3=$pth2$cntry
 echo $pth3
 echo "---------"
 cd $cntry
 ls -ldtr */ | grep -vi "newORF" | xargs rm -rf
 
 cd $pth2
 echo "----CLOSE:$pth3-----"
done
 cd $pth1
 echo "-----END:$pth2------"
 echo ""
done
echo ""
echo "-------JOB COMPLETED------"
