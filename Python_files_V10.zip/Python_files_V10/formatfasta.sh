#!/bin/bash

#	Author		-	Murali Aadhitya M S
#	Created on	-	27 ?November ?2021, ??12:23:48

#	Program to remove \n and \r from fasta files and convert into single line of sequence

filename=$1
sed -i '/^>/ s/$/@/g' $1
cat $1 | tr "\n" "~" | tr "\r" "~" >> temp1.fasta
sed -i 's/@/\n/g;s/~>/\n>/g;s/~//g;s/ /-/g' temp1.fasta
rm $1
mv temp1.fasta $1
echo "" >> $1
echo $1" has been formatted"
